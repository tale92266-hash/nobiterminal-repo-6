# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_lx_global_optspecs
    string join \n dev server= extra-servers= namespace= lua-dir= lua-version= tree= cache-dir= data-dir= vendor-dir= variables= profile= verbose no-progress no-prompt= preset= nvim no-tfa allow-root timeout= max-jobs= no-luarc no-wrap-bin user-agent= h/help V/version
end

function __fish_lx_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_lx_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_lx_using_subcommand
    set -l cmd (__fish_lx_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c lx -n "__fish_lx_needs_command" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_needs_command" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_needs_command" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_needs_command" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_needs_command" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_needs_command" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_needs_command" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_needs_command" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_needs_command" -l vendor-dir -d 'Specifies a directory with locally vendored sources and RockSpecs.{n} When building or installing a package with this flag,{n} Lux will fetch sources from the <vendor-dir> instead of from a remote server' -r -F
complete -c lx -n "__fish_lx_needs_command" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_needs_command" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_needs_command" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_needs_command" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_needs_command" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_needs_command" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_needs_command" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_needs_command" -l dev -d 'Enable the sub-repositories in luarocks servers for rockspecs of in-development versions'
complete -c lx -n "__fish_lx_needs_command" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_needs_command" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_needs_command" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_needs_command" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_needs_command" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_needs_command" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_needs_command" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_needs_command" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_needs_command" -s V -l version -d 'Print version'
complete -c lx -n "__fish_lx_needs_command" -f -a "add" -d 'Add a dependency to the current project'
complete -c lx -n "__fish_lx_needs_command" -f -a "build" -d 'Build/compile a project'
complete -c lx -n "__fish_lx_needs_command" -f -a "check" -d '[EXPERIMENTAL]{n} Type check the current project based on EmmyLua/LuaCATS annotations.{n} Respects `.emmyrc.json` and `.luarc.json` files in the project directory'
complete -c lx -n "__fish_lx_needs_command" -f -a "config" -d 'Interact with the lux configuration'
complete -c lx -n "__fish_lx_needs_command" -f -a "debug" -d 'Internal commands for debugging Lux itself'
complete -c lx -n "__fish_lx_needs_command" -f -a "dist" -d 'Distribute a Lux project'
complete -c lx -n "__fish_lx_needs_command" -f -a "doc" -d 'Show documentation for an installed rock'
complete -c lx -n "__fish_lx_needs_command" -f -a "download" -d 'Download a specific rock file from a luarocks server'
complete -c lx -n "__fish_lx_needs_command" -f -a "fmt" -d 'Formats the codebase with stylua'
complete -c lx -n "__fish_lx_needs_command" -f -a "generate-rockspec" -d 'Generate a rockspec file from a project'
complete -c lx -n "__fish_lx_needs_command" -f -a "generate-lockfile" -d 'Generate a lockfile for the current project without installing its dependencies'
complete -c lx -n "__fish_lx_needs_command" -f -a "info" -d 'Show metadata for any rock'
complete -c lx -n "__fish_lx_needs_command" -f -a "install" -d 'Install a rock for use on the system'
complete -c lx -n "__fish_lx_needs_command" -f -a "install-rockspec" -d 'Install a local rockspec for use on the system'
complete -c lx -n "__fish_lx_needs_command" -f -a "install-lua" -d 'Manually install and manage Lua headers for various Lua versions'
complete -c lx -n "__fish_lx_needs_command" -f -a "lint" -d 'Lint the current project using `luacheck`'
complete -c lx -n "__fish_lx_needs_command" -f -a "list" -d 'List currently installed rocks'
complete -c lx -n "__fish_lx_needs_command" -f -a "lua" -d 'Run lua, with the `LUA_PATH` and `LUA_CPATH` set to the specified lux tree'
complete -c lx -n "__fish_lx_needs_command" -f -a "new" -d 'Create a new Lua project'
complete -c lx -n "__fish_lx_needs_command" -f -a "outdated" -d 'List outdated rocks'
complete -c lx -n "__fish_lx_needs_command" -f -a "pack" -d 'Create a packed rock for distribution, packing sources or binaries'
complete -c lx -n "__fish_lx_needs_command" -f -a "path" -d 'Return the currently configured package path'
complete -c lx -n "__fish_lx_needs_command" -f -a "pin" -d 'Pin an existing rock, preventing any updates to the package'
complete -c lx -n "__fish_lx_needs_command" -f -a "purge" -d 'Remove all installed rocks from a tree'
complete -c lx -n "__fish_lx_needs_command" -f -a "remove" -d 'Remove a rock from the current project\'s lux.toml dependencies'
complete -c lx -n "__fish_lx_needs_command" -f -a "run" -d 'Run the current project with the provided arguments'
complete -c lx -n "__fish_lx_needs_command" -f -a "exec" -d 'Execute a command that has been installed with lux. If the command is not found, a package named after the command will be installed'
complete -c lx -n "__fish_lx_needs_command" -f -a "search" -d 'Query the luarocks servers'
complete -c lx -n "__fish_lx_needs_command" -f -a "test" -d 'Run the test suite in the current project directory.{n} Lux supports the following test backends, specified by the `[test]` table in the lux.toml:{n} {n} - busted:{n} {n} https://lunarmodules.github.io/busted/{n} {n} Example:{n} {n} ```toml{n} [test]{n} type = "busted"{n} flags = [ ] # Optional CLI flags to pass to busted{n} ```{n} {n} `lx test` will default to using `busted` if no test backend is specified and:{n} * there is a `.busted` file in the project root{n} * or `busted` is one of the `test_dependencies`).{n} {n} - busted-nlua:{n}: {n} A build backend for running busted tests with Neovim as the Lua interpreter. Used for testing Neovim plugins. {n} Example:{n} {n} ```toml{n} [test]{n} type = "busted-nlua"{n} flags = [ ] # Optional CLI flags to pass to busted{n} ```{n} {n} `lx test` will default to using `busted-nlua` if no test backend is specified and:{n} * there is a `.busted` file in the project root{n} * or `busted` and `nlua` are `test_dependencies`.{n} {n} - command:{n} {n} Name/file name of a shell command that will run the test suite.{n} Example:{n} {n} ```toml{n} [test]{n} type = "command"{n} command = "make"{n} flags = [ "test" ]{n} ```{n} {n} - script:{n} {n} Relative path to a Lua script that will run the test suite.{n} Example:{n} {n} ```toml{n} [test]{n} type = "script"{n} script = "tests.lua" # Expects a tests.lua file in the project root{n} flags = [ ] # Optional arguments passed to the test script{n} ```{n}'
complete -c lx -n "__fish_lx_needs_command" -f -a "uninstall" -d 'Uninstall a rock from the system'
complete -c lx -n "__fish_lx_needs_command" -f -a "unpin" -d 'Unpins an existing rock, allowing updates to alter the package'
complete -c lx -n "__fish_lx_needs_command" -f -a "update" -d 'Updates all rocks in a project'
complete -c lx -n "__fish_lx_needs_command" -f -a "upload" -d 'Generate a Lua rockspec for a Lux project and upload it to the public luarocks repository.{n} You can specify a source template for release and dev packages in the lux.toml.{n} {n} Example:{n} {n} ```toml{n} [source]{n} url = "https://host.com/owner/$(PACKAGE)/refs/tags/$(REF).zip"{n} dev = "git+https://host.com/owner/$(PACKAGE).git"{n} ```{n} {n} You can use the following variables in the source template:{n} {n} - $(PACKAGE): The package name.{n} - $(VERSION): The package version.{n} - $(REF): The git tag or revision (if in a git repository).{n} - You may also specify environment variables with `$(<VAR_NAME>)`.{n} {n} If the `version` is not set in the lux.toml, lux will search the current commit for SemVer tags and if found, will use it to generate the package version'
complete -c lx -n "__fish_lx_needs_command" -f -a "util" -d 'Infrequently used commands such as for generating shell completions and man pages'
complete -c lx -n "__fish_lx_needs_command" -f -a "vendor" -d 'Vendor the dependencies of a project or RockSpec locally. When building or installing a package with the `--vendor-dir` option{n} or the `[vendor_dir]` config option, Lux will fetch sources from the <vendor-dir>{n} instead of from a remote server'
complete -c lx -n "__fish_lx_needs_command" -f -a "which" -d 'Tell which file corresponds to a given module name'
complete -c lx -n "__fish_lx_needs_command" -f -a "shell" -d 'Spawns an interactive shell with PATH, LUA_PATH, LUA_CPATH and LUA_INIT set'
complete -c lx -n "__fish_lx_needs_command" -f -a "sync" -d 'Synchronize the project tree with the current lux.toml,{n} ensuring all packages are installed correctly'
complete -c lx -n "__fish_lx_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c lx -n "__fish_lx_using_subcommand add" -s b -s d -s b -l build -d 'Install the package as a development dependency. {n} Also called `dev`' -r
complete -c lx -n "__fish_lx_using_subcommand add" -s t -s t -l test -d 'Install the package as a test dependency' -r
complete -c lx -n "__fish_lx_using_subcommand add" -s p -s p -l package -d 'Project to modify' -r
complete -c lx -n "__fish_lx_using_subcommand add" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand add" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand add" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand add" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand add" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand add" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand add" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand add" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand add" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand add" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand add" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand add" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand add" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand add" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand add" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand add" -l force -d 'Reinstall without prompt if a package is already installed'
complete -c lx -n "__fish_lx_using_subcommand add" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand add" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand add" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand add" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand add" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand add" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand add" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand add" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand build" -s p -s p -l package -d 'Package to build' -r
complete -c lx -n "__fish_lx_using_subcommand build" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand build" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand build" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand build" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand build" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand build" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand build" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand build" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand build" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand build" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand build" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand build" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand build" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand build" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand build" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand build" -l no-lock -d 'Ignore the project\'s lockfile and don\'t create one'
complete -c lx -n "__fish_lx_using_subcommand build" -l only-deps -d 'Build only the dependencies'
complete -c lx -n "__fish_lx_using_subcommand build" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand build" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand build" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand build" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand build" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand build" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand build" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand build" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand check" -l path -d 'Path to a workspace, directory, or Lua file to check. Defaults to the current workspace' -r -F
complete -c lx -n "__fish_lx_using_subcommand check" -s i -l ignore -d 'Comma-separated list of ignore patterns. Patterns must follow glob syntax. Lux will automatically add top-level ignored project files' -r
complete -c lx -n "__fish_lx_using_subcommand check" -l output-format -d 'The output format' -r -f -a "json\t''
text\t''"
complete -c lx -n "__fish_lx_using_subcommand check" -l output -d 'Output destination.{n} (stdout or a file path, only used when the output format is json)' -r
complete -c lx -n "__fish_lx_using_subcommand check" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand check" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand check" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand check" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand check" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand check" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand check" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand check" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand check" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand check" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand check" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand check" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand check" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand check" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand check" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand check" -l warnings-as-errors -d 'Treat warnings as errors'
complete -c lx -n "__fish_lx_using_subcommand check" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand check" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand check" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand check" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand check" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand check" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand check" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand check" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -f -a "init" -d 'Initialise a new config file'
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -f -a "edit" -d 'Edit the current config file'
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -f -a "show" -d 'Show the current config. This includes options picked up from CLI flags'
complete -c lx -n "__fish_lx_using_subcommand config; and not __fish_seen_subcommand_from init edit show help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l default -d 'Initialise the default config for this system. If this flag is not set, an empty config file will be created'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l current -d 'Initialise the config file using the current config, with options picked up from CLI flags'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l workspace -d 'Initialise the config in the current workspace'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from init" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l workspace -d 'Edit the current workspace config'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from edit" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from show" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "init" -d 'Initialise a new config file'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "edit" -d 'Edit the current config file'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "show" -d 'Show the current config. This includes options picked up from CLI flags'
complete -c lx -n "__fish_lx_using_subcommand config; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -f -a "unpack" -d 'Unpack the contents of a rock'
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -f -a "fetch-remote" -d 'Fetch a remote rock from its RockSpec source'
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -f -a "unpack-remote" -d 'Download a .src.rock from luarocks.org and unpack it'
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -f -a "project" -d 'View information about the current project'
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -f -a "toolchains" -d 'Check for available toolchains'
complete -c lx -n "__fish_lx_using_subcommand debug; and not __fish_seen_subcommand_from unpack fetch-remote unpack-remote project toolchains help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from fetch-remote" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from unpack-remote" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l list-files -d 'List files that are included. To avoid copying large files that are not relevant to the build process, Lux excludes hidden files and files that are ignored (e.g. by .gitignore or other .ignore files)'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from project" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l output-format -d 'The output format' -r -f -a "json\t''
text\t''"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from toolchains" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from help" -f -a "unpack" -d 'Unpack the contents of a rock'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from help" -f -a "fetch-remote" -d 'Fetch a remote rock from its RockSpec source'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from help" -f -a "unpack-remote" -d 'Download a .src.rock from luarocks.org and unpack it'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from help" -f -a "project" -d 'View information about the current project'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from help" -f -a "toolchains" -d 'Check for available toolchains'
complete -c lx -n "__fish_lx_using_subcommand debug; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -f -a "flat-archive" -d 'Distribute an archive of a flat install tree which includes all dependencies.{n} The resulting archive does not include the `etc` directory or build dependencies.{n} Unlike a Lux tree, dependency conflicts are not supported/handled'
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -f -a "bin" -d 'Compile a Lux project, including its dependencies, into a single binary,{n} which runs on systems that do not have Lua installed.{n} Projects with native Lua modules are not single binaries: the modules are{n} copied as shared libraries next to the output binary, and must be{n} shipped alongside it.{n} As with flat-archive, dependency conflicts are not supported/handled.{n} {n} The entrypoint is specified via the lux.toml\'s [run] field, e.g.: {n} {n} ```toml{n} [run]{n} args = ["src/main.lua"]{n} ```'
complete -c lx -n "__fish_lx_using_subcommand dist; and not __fish_seen_subcommand_from flat-archive bin help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -s d -s d -l destination -d 'The destination path. Defaults to \'<cwd>/<package>-<version>.zip\'.{n}' -r -F
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -s c -s c -l compression-method -r -f -a "stored\t'Store the install tree as is'
deflated\t'Compress the install tree using Deflate'
bzip2\t'Compress the install tree using BZIP2'
xz\t'Compress the install tree using XZ'
zstd\t'Compress the install tree using `ZStandard`'
lzma\t'Compress the install tree using LZMA'"
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l output-format -r -f -a "json\t''
text\t''"
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from flat-archive" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -s o -s o -l output -d 'Output path for the compiled binary.{n} Defaults to `<package>[.exe]` in the current directory' -r -F
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -s p -s p -l package -d 'Package to compile.{n} Prioritises local projects if in a workspace.{n} If not set, lux will attempt to compile the current project.{n} Must be set in multi-project workspaces' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l output-format -r -f -a "json\t''
text\t''"
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from bin" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from help" -f -a "flat-archive" -d 'Distribute an archive of a flat install tree which includes all dependencies.{n} The resulting archive does not include the `etc` directory or build dependencies.{n} Unlike a Lux tree, dependency conflicts are not supported/handled'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from help" -f -a "bin" -d 'Compile a Lux project, including its dependencies, into a single binary,{n} which runs on systems that do not have Lua installed.{n} Projects with native Lua modules are not single binaries: the modules are{n} copied as shared libraries next to the output binary, and must be{n} shipped alongside it.{n} As with flat-archive, dependency conflicts are not supported/handled.{n} {n} The entrypoint is specified via the lux.toml\'s [run] field, e.g.: {n} {n} ```toml{n} [run]{n} args = ["src/main.lua"]{n} ```'
complete -c lx -n "__fish_lx_using_subcommand dist; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c lx -n "__fish_lx_using_subcommand doc" -s p -s p -l package -d 'The package to show documentation for.{n} If not set, lux will use the package installed in the tree,{n} or prompt to select one if the tree has many' -r
complete -c lx -n "__fish_lx_using_subcommand doc" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand doc" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand doc" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand doc" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand doc" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand doc" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand doc" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand doc" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand doc" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand doc" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand doc" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand doc" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand doc" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand doc" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand doc" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand doc" -l online -d 'Ignore local docs and open the package\'s homepage in a browser'
complete -c lx -n "__fish_lx_using_subcommand doc" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand doc" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand doc" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand doc" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand doc" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand doc" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand doc" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand doc" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand download" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand download" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand download" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand download" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand download" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand download" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand download" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand download" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand download" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand download" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand download" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand download" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand download" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand download" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand download" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand download" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand download" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand download" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand download" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand download" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand download" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand download" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand download" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand fmt" -l path -d 'Path to a workspace, directory, or Lua file to format. Defaults to the current workspace' -r -F
complete -c lx -n "__fish_lx_using_subcommand fmt" -l backend -r -f -a "stylua\t'Mainly follows the [Roblox Lua style guide](https://roblox.github.io/lua-style-guide/)'
luafmt\t'The default formatter used by [emmylua-analyzer-rust](https://github.com/EmmyLuaLs/emmylua-analyzer-rust). If invoked with `lx --lua-version=<version> fmt`, Lux will configure the luafmt syntax level to match the specified Lua version'
emmylua-codestyle\t'The default formatter used by [lua-language-server](https://luals.github.io/)'"
complete -c lx -n "__fish_lx_using_subcommand fmt" -s p -s p -l package -d 'Package to format' -r
complete -c lx -n "__fish_lx_using_subcommand fmt" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand fmt" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand fmt" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand fmt" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand fmt" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand fmt" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand fmt" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand fmt" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand fmt" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand fmt" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand fmt" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand fmt" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand fmt" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand fmt" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand fmt" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand fmt" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand fmt" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand fmt" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand fmt" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand fmt" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand fmt" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand fmt" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand fmt" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -s p -s p -l package -d 'Package to generate the rockspec for' -r
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l version -d 'Version to generate the rockspec for (e.g. `dev`, `scm` or `1.2.3`).{n} Defaults to the version in `lux.toml`' -r
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l output-format -r -f -a "json\t''
text\t''"
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand generate-rockspec" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand generate-lockfile" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand info" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand info" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand info" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand info" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand info" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand info" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand info" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand info" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand info" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand info" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand info" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand info" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand info" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand info" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand info" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand info" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand info" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand info" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand info" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand info" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand info" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand info" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand info" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand install" -l path -d 'Install a local project from this directory, rather than a remote package' -r -F
complete -c lx -n "__fish_lx_using_subcommand install" -s p -s p -l package -d 'Package to install when installing from a multi-project workspace. Ignored if the `--path` option is unset' -r
complete -c lx -n "__fish_lx_using_subcommand install" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand install" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand install" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand install" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand install" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand install" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand install" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand install" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand install" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand install" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand install" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand install" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand install" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand install" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand install" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand install" -l pin -d 'Pin the packages so that they don\'t get updated'
complete -c lx -n "__fish_lx_using_subcommand install" -l force -d 'Reinstall without prompt if a package is already installed'
complete -c lx -n "__fish_lx_using_subcommand install" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand install" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand install" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand install" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand install" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand install" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand install" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand install" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l pin -d 'Whether to pin the installed package and dependencies'
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand install-rockspec" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand install-lua" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand install-lua" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand lint" -l path -d 'Path to a workspace, directory, or Lua file to lint. Defaults to the current workspace' -r -F
complete -c lx -n "__fish_lx_using_subcommand lint" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand lint" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand lint" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand lint" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand lint" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand lint" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand lint" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand lint" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand lint" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand lint" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand lint" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand lint" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand lint" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand lint" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand lint" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand lint" -l no-ignore -d 'By default, Lux will add top-level ignored files and directories{n} (like those in .gitignore) to luacheck\'s exclude files.{n} This flag disables that behaviour.{n}'
complete -c lx -n "__fish_lx_using_subcommand lint" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand lint" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand lint" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand lint" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand lint" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand lint" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand lint" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand lint" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand list" -l output-format -r -f -a "json\t''
text\t''"
complete -c lx -n "__fish_lx_using_subcommand list" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand list" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand list" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand list" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand list" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand list" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand list" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand list" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand list" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand list" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand list" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand list" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand list" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand list" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand list" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand list" -l orphans -d 'Only list rocks that are not reachable from an entrypoint'
complete -c lx -n "__fish_lx_using_subcommand list" -l removable -d 'Only list rocks that are not a dependency of any other rock'
complete -c lx -n "__fish_lx_using_subcommand list" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand list" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand list" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand list" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand list" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand list" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand list" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand list" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand lua" -l lua -d 'Path to the Lua interpreter to use' -r
complete -c lx -n "__fish_lx_using_subcommand lua" -s p -s p -l package -d 'Package to build' -r
complete -c lx -n "__fish_lx_using_subcommand lua" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand lua" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand lua" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand lua" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand lua" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand lua" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand lua" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand lua" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand lua" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand lua" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand lua" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand lua" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand lua" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand lua" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand lua" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand lua" -l test -d 'Add test dependencies to the environment'
complete -c lx -n "__fish_lx_using_subcommand lua" -l build -d 'Add build dependencies to the environment'
complete -c lx -n "__fish_lx_using_subcommand lua" -l no-loader -d 'Disable the Lux loader. If a rock has conflicting transitive dependencies, disabling the Lux loader may result in the wrong modules being loaded'
complete -c lx -n "__fish_lx_using_subcommand lua" -l pure -d 'Only load packages from the current project. Does not inherit user-installed packages or system Lua paths. This is the default when running inside a project'
complete -c lx -n "__fish_lx_using_subcommand lua" -l impure -d 'Also expose user-installed packages and system Lua paths. This is the default when running outside a project'
complete -c lx -n "__fish_lx_using_subcommand lua" -l no-lock -d 'Ignore the project\'s lockfile and don\'t create one'
complete -c lx -n "__fish_lx_using_subcommand lua" -l only-deps -d 'Build only the dependencies'
complete -c lx -n "__fish_lx_using_subcommand lua" -l help -d 'Print help'
complete -c lx -n "__fish_lx_using_subcommand lua" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand lua" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand lua" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand lua" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand lua" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand lua" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand lua" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand new" -l name -d 'The project\'s name' -r
complete -c lx -n "__fish_lx_using_subcommand new" -l description -d 'The description of the project' -r
complete -c lx -n "__fish_lx_using_subcommand new" -l license -d 'The license of the project. Generic license names will be inferred' -r
complete -c lx -n "__fish_lx_using_subcommand new" -l maintainer -d 'The maintainer of this project. Does not have to be the code author' -r
complete -c lx -n "__fish_lx_using_subcommand new" -l labels -d 'A comma-separated list of labels to apply to this project' -r
complete -c lx -n "__fish_lx_using_subcommand new" -l lua-versions -d 'A version constraint on the required Lua version for this project. Examples: ">=5.1", "5.1"' -r
complete -c lx -n "__fish_lx_using_subcommand new" -l main -r -f -a "src\t''
lua\t''
none\t''"
complete -c lx -n "__fish_lx_using_subcommand new" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand new" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand new" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand new" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand new" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand new" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand new" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand new" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand new" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand new" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand new" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand new" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand new" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand new" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand new" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand new" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand new" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand new" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand new" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand new" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand new" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand new" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand new" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand outdated" -l output-format -r -f -a "json\t''
text\t''"
complete -c lx -n "__fish_lx_using_subcommand outdated" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand outdated" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand outdated" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand outdated" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand outdated" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand outdated" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand outdated" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand outdated" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand outdated" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand outdated" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand outdated" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand outdated" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand outdated" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand outdated" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand outdated" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand outdated" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand outdated" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand outdated" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand outdated" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand outdated" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand outdated" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand outdated" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand outdated" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand pack" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand pack" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand pack" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand pack" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand pack" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand pack" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand pack" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand pack" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand pack" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand pack" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand pack" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand pack" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand pack" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand pack" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand pack" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand pack" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand pack" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand pack" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand pack" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand pack" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand pack" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand pack" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand pack" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l prepend -d 'Prepend the rocks tree paths to the system paths'
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -f -a "full" -d 'Generate an export statement for all paths (formatted as a shell command). [Default]'
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -f -a "lua" -d 'Generate a `LUA_PATH` expression for `lua` libraries in the lux tree. (not formatted as a shell command)'
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -f -a "c" -d 'Generate a `LUA_CPATH` expression for native `lib` libraries in the lux tree. (not formatted as a shell command)'
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -f -a "bin" -d 'Generate a `PATH` expression for `bin` executables in the lux tree. (not formatted as a shell command)'
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -f -a "init" -d 'Generate a `LUA_INIT` expression for the lux loader. (not formatted as a shell command)'
complete -c lx -n "__fish_lx_using_subcommand path; and not __fish_seen_subcommand_from full lua c bin init help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l shell -d 'The shell to format for' -r -f -a "posix\t''
fish\t''
nu\t''"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l no-bin -d 'Do not export `PATH` (`bin` paths)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l no-loader -d 'Do not add `require(\'lux\').loader()` to `LUA_INIT`. If a rock has conflicting transitive dependencies, disabling the Lux loader may result in the wrong modules being loaded'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from full" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from lua" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from c" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from bin" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from init" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from help" -f -a "full" -d 'Generate an export statement for all paths (formatted as a shell command). [Default]'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from help" -f -a "lua" -d 'Generate a `LUA_PATH` expression for `lua` libraries in the lux tree. (not formatted as a shell command)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from help" -f -a "c" -d 'Generate a `LUA_CPATH` expression for native `lib` libraries in the lux tree. (not formatted as a shell command)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from help" -f -a "bin" -d 'Generate a `PATH` expression for `bin` executables in the lux tree. (not formatted as a shell command)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from help" -f -a "init" -d 'Generate a `LUA_INIT` expression for the lux loader. (not formatted as a shell command)'
complete -c lx -n "__fish_lx_using_subcommand path; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c lx -n "__fish_lx_using_subcommand pin" -s b -s d -s b -l build -d 'Pin a development dependency. Also called `dev`' -r
complete -c lx -n "__fish_lx_using_subcommand pin" -s t -l test -d 'Pin a test dependency' -r
complete -c lx -n "__fish_lx_using_subcommand pin" -s p -s p -l package -d 'Project to modify' -r
complete -c lx -n "__fish_lx_using_subcommand pin" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand pin" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand pin" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand pin" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand pin" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand pin" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand pin" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand pin" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand pin" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand pin" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand pin" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand pin" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand pin" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand pin" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand pin" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand pin" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand pin" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand pin" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand pin" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand pin" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand pin" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand pin" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand pin" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand purge" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand purge" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand purge" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand purge" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand purge" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand purge" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand purge" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand purge" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand purge" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand purge" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand purge" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand purge" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand purge" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand purge" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand purge" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand purge" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand purge" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand purge" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand purge" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand purge" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand purge" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand purge" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand purge" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand remove" -s b -s d -s b -l build -d 'Remove a development dependency. Also called `dev`' -r
complete -c lx -n "__fish_lx_using_subcommand remove" -s t -l test -d 'Remove a test dependency' -r
complete -c lx -n "__fish_lx_using_subcommand remove" -s p -s p -l package -d 'Package to remove from' -r
complete -c lx -n "__fish_lx_using_subcommand remove" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand remove" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand remove" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand remove" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand remove" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand remove" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand remove" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand remove" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand remove" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand remove" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand remove" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand remove" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand remove" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand remove" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand remove" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand remove" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand remove" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand remove" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand remove" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand remove" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand remove" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand remove" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand remove" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand run" -l dir -d 'Path in which to run the command.{n} Defaults to the project root' -r -F
complete -c lx -n "__fish_lx_using_subcommand run" -s p -s p -l package -d 'Package to build' -r
complete -c lx -n "__fish_lx_using_subcommand run" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand run" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand run" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand run" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand run" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand run" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand run" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand run" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand run" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand run" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand run" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand run" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand run" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand run" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand run" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand run" -l no-loader -d 'Do not add `require(\'lux\').loader()` to `LUA_INIT`.{n} If a rock has conflicting transitive dependencies,{n} disabling the Lux loader may result in the wrong modules being loaded'
complete -c lx -n "__fish_lx_using_subcommand run" -l impure -d 'Also expose user-installed packages and system Lua paths'
complete -c lx -n "__fish_lx_using_subcommand run" -l no-lock -d 'Ignore the project\'s lockfile and don\'t create one'
complete -c lx -n "__fish_lx_using_subcommand run" -l only-deps -d 'Build only the dependencies'
complete -c lx -n "__fish_lx_using_subcommand run" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand run" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand run" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand run" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand run" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand run" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand run" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand run" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand exec" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand exec" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand exec" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand exec" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand exec" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand exec" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand exec" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand exec" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand exec" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand exec" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand exec" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand exec" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand exec" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand exec" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand exec" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand exec" -l no-loader -d 'Do not add `require(\'lux\').loader()` to `LUA_INIT`. If a rock has conflicting transitive dependencies, disabling the Lux loader may result in the wrong modules being loaded'
complete -c lx -n "__fish_lx_using_subcommand exec" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand exec" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand exec" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand exec" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand exec" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand exec" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand exec" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand exec" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand search" -l output-format -r -f -a "json\t''
text\t''"
complete -c lx -n "__fish_lx_using_subcommand search" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand search" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand search" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand search" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand search" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand search" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand search" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand search" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand search" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand search" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand search" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand search" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand search" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand search" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand search" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand search" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand search" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand search" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand search" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand search" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand search" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand search" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand search" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand test" -s p -s p -l package -d 'Package to run tests for' -r
complete -c lx -n "__fish_lx_using_subcommand test" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand test" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand test" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand test" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand test" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand test" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand test" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand test" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand test" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand test" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand test" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand test" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand test" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand test" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand test" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand test" -l impure -d 'Don\'t isolate the user environment (keep `HOME` and `XDG` environment variables)'
complete -c lx -n "__fish_lx_using_subcommand test" -l no-lock -d 'Ignore the project\'s lockfile and don\'t create one'
complete -c lx -n "__fish_lx_using_subcommand test" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand test" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand test" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand test" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand test" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand test" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand test" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand test" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand uninstall" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand uninstall" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand unpin" -s b -s d -s b -l build -d 'Pin a development dependency. Also called `dev`' -r
complete -c lx -n "__fish_lx_using_subcommand unpin" -s t -l test -d 'Pin a test dependency' -r
complete -c lx -n "__fish_lx_using_subcommand unpin" -s p -s p -l package -d 'Project to modify' -r
complete -c lx -n "__fish_lx_using_subcommand unpin" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand unpin" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand unpin" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand unpin" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand unpin" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand unpin" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand unpin" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand unpin" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand unpin" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand unpin" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand unpin" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand unpin" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand unpin" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand unpin" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand unpin" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand unpin" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand unpin" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand unpin" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand unpin" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand unpin" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand unpin" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand unpin" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand unpin" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand update" -s b -s d -s b -l build -d 'Build dependencies to update. Also called `dev`. When updating a project, these must be package names' -r
complete -c lx -n "__fish_lx_using_subcommand update" -s t -l test -d 'Build dependencies to update. When updating a project, these must be package names' -r
complete -c lx -n "__fish_lx_using_subcommand update" -s p -s p -l package -d 'Project to modify' -r
complete -c lx -n "__fish_lx_using_subcommand update" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand update" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand update" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand update" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand update" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand update" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand update" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand update" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand update" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand update" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand update" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand update" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand update" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand update" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand update" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand update" -l no-integrity-check -d 'Skip the integrity checks for installed rocks when syncing the project lockfile'
complete -c lx -n "__fish_lx_using_subcommand update" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand update" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand update" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand update" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand update" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand update" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand update" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand update" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand upload" -l sign-protocol -d 'The protocol to use when signing upload artefacts' -r -f -a "none\t''
assuan\t''
cms\t''
default\t''
g13\t''
gpgconf\t''
openpgp\t''
spawn\t''
uiserver\t''"
complete -c lx -n "__fish_lx_using_subcommand upload" -s p -s p -l package -d 'Package to upload' -r
complete -c lx -n "__fish_lx_using_subcommand upload" -l output-format -d 'The output format' -r -f -a "json\t''
text\t''"
complete -c lx -n "__fish_lx_using_subcommand upload" -s t -s c -l tfa-code -d 'Code to use for two-factor authentication (2FA).{n} It is recommended to enable 2FA for luarocks uploads (see https://luarocks.org/settings/two-factor-auth).{n} Lux can also generate a TOTP code if you expose your luarocks.org 2FA secret via the \'LUAROCKS_2FA_SECRET\' environment variable.{n}' -r
complete -c lx -n "__fish_lx_using_subcommand upload" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand upload" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand upload" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand upload" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand upload" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand upload" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand upload" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand upload" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand upload" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand upload" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand upload" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand upload" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand upload" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand upload" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand upload" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand upload" -l dry-run -d 'Print what would be uploaded, without uploading'
complete -c lx -n "__fish_lx_using_subcommand upload" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand upload" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand upload" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand upload" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand upload" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand upload" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand upload" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand upload" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -f -a "completion" -d 'Generate autocompletion scripts for the shell.{n} Example: `lx completion zsh > ~/.zsh/completions/_lx`'
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -f -a "man" -d 'Generate manpages'
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -f -a "schema" -d 'Generate the JSON Schema for `lux.toml` or `config.toml`'
complete -c lx -n "__fish_lx_using_subcommand util; and not __fish_seen_subcommand_from completion man schema help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l target-dir -d 'The target directory in which to save completions. If not set, Lux will print the completions to stdout' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from completion" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l target-dir -d 'The target directory in which to save man pages' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from man" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l kind -d 'Which schema to generate' -r -f -a "lux-toml\t'The project manifest (`lux.toml`)'
config\t'The Lux configuration file (`config.toml`)'"
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l output-format -d 'Output format: `json` (JSON Schema) or `text` (Markdown)' -r -f -a "json\t''
text\t''"
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from schema" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from help" -f -a "completion" -d 'Generate autocompletion scripts for the shell.{n} Example: `lx completion zsh > ~/.zsh/completions/_lx`'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from help" -f -a "man" -d 'Generate manpages'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from help" -f -a "schema" -d 'Generate the JSON Schema for `lux.toml` or `config.toml`'
complete -c lx -n "__fish_lx_using_subcommand util; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c lx -n "__fish_lx_using_subcommand vendor" -l rockspec -d 'RockSpec to vendor the packages for.{n} If not set, Lux will vendor dependencies of the current project' -r -F
complete -c lx -n "__fish_lx_using_subcommand vendor" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand vendor" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand vendor" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand vendor" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand vendor" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand vendor" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand vendor" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand vendor" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand vendor" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand vendor" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand vendor" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand vendor" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand vendor" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand vendor" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand vendor" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand vendor" -l no-lock -d 'Ignore the project\'s lockfile, if present'
complete -c lx -n "__fish_lx_using_subcommand vendor" -l no-delete -d 'Don\'t delete the <vendor-dir> when vendoring,{n} but rather keep all existing contents of the vendor directory'
complete -c lx -n "__fish_lx_using_subcommand vendor" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand vendor" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand vendor" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand vendor" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand vendor" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand vendor" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand vendor" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand vendor" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand which" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand which" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand which" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand which" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand which" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand which" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand which" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand which" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand which" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand which" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand which" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand which" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand which" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand which" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand which" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand which" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand which" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand which" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand which" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand which" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand which" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand which" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand which" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand shell" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand shell" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand shell" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand shell" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand shell" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand shell" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand shell" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand shell" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand shell" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand shell" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand shell" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand shell" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand shell" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand shell" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand shell" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand shell" -l test -d 'Add test dependencies to the shell\'s paths,{n} in addition to the regular dependencies'
complete -c lx -n "__fish_lx_using_subcommand shell" -l build -d 'Add *only* build dependencies to the shell\'s paths'
complete -c lx -n "__fish_lx_using_subcommand shell" -l no-loader -d 'Disable the Lux loader.{n} If a rock has conflicting transitive dependencies,{n} disabling the Lux loader may result in the wrong modules being loaded.{n}'
complete -c lx -n "__fish_lx_using_subcommand shell" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand shell" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand shell" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand shell" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand shell" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand shell" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand shell" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand shell" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand sync" -l server -d 'Fetch rocks/rockspecs from this server (takes priority over config file)' -r
complete -c lx -n "__fish_lx_using_subcommand sync" -l extra-servers -d 'Fetch rocks/rockspecs from these servers in addition to the main server{n} (overrides any entries in the config file)' -r
complete -c lx -n "__fish_lx_using_subcommand sync" -l namespace -d 'Specify the luarocks server namespace to use' -r
complete -c lx -n "__fish_lx_using_subcommand sync" -l lua-dir -d 'Specify the directory in which to install Lua if not found' -r -F
complete -c lx -n "__fish_lx_using_subcommand sync" -l lua-version -d 'Which Lua installation to use.{n} Valid versions are: \'5.1\', \'5.2\', \'5.3\', \'5.4\', \'5.5\', \'jit\' and \'jit52\'.{n} If not set, Lux will attempt to detect the Lua version:{n} - From the current project, if it has an exact Lua version requirement.{n} - From the Lua installation that is available on the PATH' -r
complete -c lx -n "__fish_lx_using_subcommand sync" -l tree -d 'Which tree to operate on.{n} In a workspace, this can be used to specify a detached workspace tree' -r -F
complete -c lx -n "__fish_lx_using_subcommand sync" -l cache-dir -d 'Specifies the cache directory, e.g. for luarocks manifests' -r -F
complete -c lx -n "__fish_lx_using_subcommand sync" -l data-dir -d 'Specifies the data directory,{n} in which the default user install tree resides{n} (e.g. ~/.local/share/lux)' -r -F
complete -c lx -n "__fish_lx_using_subcommand sync" -l variables -d 'Override config variables.{n} Example: `lx -v "LUA=/path/to/lua" ...`' -r
complete -c lx -n "__fish_lx_using_subcommand sync" -l profile -d 'The build profile to use when compiling packages.{n} Default: `release`' -r -f -a "release\t''
dev\t''"
complete -c lx -n "__fish_lx_using_subcommand sync" -l no-prompt -d 'Skip prompts, selecting the default option.{n} Prompting is enabled by default in terminal/TTY environments' -r -f -a "true\t''
false\t''"
complete -c lx -n "__fish_lx_using_subcommand sync" -l preset -d 'Configure Lux for a specific environment.{n} Valid presets are: \'nvim\', \'rojo\'' -r -f -a "nvim\t'Configure Lux for [Neovim](https://neovim.io/) plugins'
rojo\t'Configure Lux for [Rojo](https://rojo.space/)'"
complete -c lx -n "__fish_lx_using_subcommand sync" -l timeout -d 'Timeout on network operations, in seconds.{n} 0 means no timeout (wait forever). Default is 30' -r
complete -c lx -n "__fish_lx_using_subcommand sync" -l max-jobs -d 'Maximum buffer size for parallel jobs, such as downloading rockspecs and installing rocks. 0 means no limit. Default is 0' -r
complete -c lx -n "__fish_lx_using_subcommand sync" -l user-agent -d 'The user agent to set when making web requests. Default is "lux/<version>"' -r
complete -c lx -n "__fish_lx_using_subcommand sync" -l no-integrity-check -d 'Skip the integrity checks for installed rocks when syncing the project lockfile'
complete -c lx -n "__fish_lx_using_subcommand sync" -l verbose -d 'Display verbose output of commands executed, enabling DEBUG logs.{n} To enable TRACE logs, set RUST_LOG=trace'
complete -c lx -n "__fish_lx_using_subcommand sync" -l no-progress -d 'Don\'t print any progress bars or spinners'
complete -c lx -n "__fish_lx_using_subcommand sync" -l nvim -d '[DEPRECATED] Configure lux for installing Neovim packages.{n} Use `--preset nvim` instead'
complete -c lx -n "__fish_lx_using_subcommand sync" -l no-tfa -d 'Disable prompts for two-factor authentication (2FA) codes.{n} It is strongly recommended to enable 2FA instead see (https://luarocks.org/settings/two-factor-auth)'
complete -c lx -n "__fish_lx_using_subcommand sync" -l allow-root -d 'Allow Lux to run as root (linux) or Administrator (windows)'
complete -c lx -n "__fish_lx_using_subcommand sync" -l no-luarc -d 'Do not generate or update a `.luarc.json` file when building{n} a project'
complete -c lx -n "__fish_lx_using_subcommand sync" -l no-wrap-bin -d 'Do not wrap Lua `bin` scripts'
complete -c lx -n "__fish_lx_using_subcommand sync" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "add" -d 'Add a dependency to the current project'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "build" -d 'Build/compile a project'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "check" -d '[EXPERIMENTAL]{n} Type check the current project based on EmmyLua/LuaCATS annotations.{n} Respects `.emmyrc.json` and `.luarc.json` files in the project directory'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "config" -d 'Interact with the lux configuration'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "debug" -d 'Internal commands for debugging Lux itself'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "dist" -d 'Distribute a Lux project'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "doc" -d 'Show documentation for an installed rock'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "download" -d 'Download a specific rock file from a luarocks server'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "fmt" -d 'Formats the codebase with stylua'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "generate-rockspec" -d 'Generate a rockspec file from a project'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "generate-lockfile" -d 'Generate a lockfile for the current project without installing its dependencies'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "info" -d 'Show metadata for any rock'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "install" -d 'Install a rock for use on the system'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "install-rockspec" -d 'Install a local rockspec for use on the system'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "install-lua" -d 'Manually install and manage Lua headers for various Lua versions'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "lint" -d 'Lint the current project using `luacheck`'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "list" -d 'List currently installed rocks'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "lua" -d 'Run lua, with the `LUA_PATH` and `LUA_CPATH` set to the specified lux tree'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "new" -d 'Create a new Lua project'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "outdated" -d 'List outdated rocks'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "pack" -d 'Create a packed rock for distribution, packing sources or binaries'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "path" -d 'Return the currently configured package path'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "pin" -d 'Pin an existing rock, preventing any updates to the package'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "purge" -d 'Remove all installed rocks from a tree'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "remove" -d 'Remove a rock from the current project\'s lux.toml dependencies'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "run" -d 'Run the current project with the provided arguments'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "exec" -d 'Execute a command that has been installed with lux. If the command is not found, a package named after the command will be installed'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "search" -d 'Query the luarocks servers'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "test" -d 'Run the test suite in the current project directory.{n} Lux supports the following test backends, specified by the `[test]` table in the lux.toml:{n} {n} - busted:{n} {n} https://lunarmodules.github.io/busted/{n} {n} Example:{n} {n} ```toml{n} [test]{n} type = "busted"{n} flags = [ ] # Optional CLI flags to pass to busted{n} ```{n} {n} `lx test` will default to using `busted` if no test backend is specified and:{n} * there is a `.busted` file in the project root{n} * or `busted` is one of the `test_dependencies`).{n} {n} - busted-nlua:{n}: {n} A build backend for running busted tests with Neovim as the Lua interpreter. Used for testing Neovim plugins. {n} Example:{n} {n} ```toml{n} [test]{n} type = "busted-nlua"{n} flags = [ ] # Optional CLI flags to pass to busted{n} ```{n} {n} `lx test` will default to using `busted-nlua` if no test backend is specified and:{n} * there is a `.busted` file in the project root{n} * or `busted` and `nlua` are `test_dependencies`.{n} {n} - command:{n} {n} Name/file name of a shell command that will run the test suite.{n} Example:{n} {n} ```toml{n} [test]{n} type = "command"{n} command = "make"{n} flags = [ "test" ]{n} ```{n} {n} - script:{n} {n} Relative path to a Lua script that will run the test suite.{n} Example:{n} {n} ```toml{n} [test]{n} type = "script"{n} script = "tests.lua" # Expects a tests.lua file in the project root{n} flags = [ ] # Optional arguments passed to the test script{n} ```{n}'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "uninstall" -d 'Uninstall a rock from the system'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "unpin" -d 'Unpins an existing rock, allowing updates to alter the package'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "update" -d 'Updates all rocks in a project'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "upload" -d 'Generate a Lua rockspec for a Lux project and upload it to the public luarocks repository.{n} You can specify a source template for release and dev packages in the lux.toml.{n} {n} Example:{n} {n} ```toml{n} [source]{n} url = "https://host.com/owner/$(PACKAGE)/refs/tags/$(REF).zip"{n} dev = "git+https://host.com/owner/$(PACKAGE).git"{n} ```{n} {n} You can use the following variables in the source template:{n} {n} - $(PACKAGE): The package name.{n} - $(VERSION): The package version.{n} - $(REF): The git tag or revision (if in a git repository).{n} - You may also specify environment variables with `$(<VAR_NAME>)`.{n} {n} If the `version` is not set in the lux.toml, lux will search the current commit for SemVer tags and if found, will use it to generate the package version'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "util" -d 'Infrequently used commands such as for generating shell completions and man pages'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "vendor" -d 'Vendor the dependencies of a project or RockSpec locally. When building or installing a package with the `--vendor-dir` option{n} or the `[vendor_dir]` config option, Lux will fetch sources from the <vendor-dir>{n} instead of from a remote server'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "which" -d 'Tell which file corresponds to a given module name'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "shell" -d 'Spawns an interactive shell with PATH, LUA_PATH, LUA_CPATH and LUA_INIT set'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "sync" -d 'Synchronize the project tree with the current lux.toml,{n} ensuring all packages are installed correctly'
complete -c lx -n "__fish_lx_using_subcommand help; and not __fish_seen_subcommand_from add build check config debug dist doc download fmt generate-rockspec generate-lockfile info install install-rockspec install-lua lint list lua new outdated pack path pin purge remove run exec search test uninstall unpin update upload util vendor which shell sync help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "init" -d 'Initialise a new config file'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "edit" -d 'Edit the current config file'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from config" -f -a "show" -d 'Show the current config. This includes options picked up from CLI flags'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from debug" -f -a "unpack" -d 'Unpack the contents of a rock'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from debug" -f -a "fetch-remote" -d 'Fetch a remote rock from its RockSpec source'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from debug" -f -a "unpack-remote" -d 'Download a .src.rock from luarocks.org and unpack it'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from debug" -f -a "project" -d 'View information about the current project'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from debug" -f -a "toolchains" -d 'Check for available toolchains'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from dist" -f -a "flat-archive" -d 'Distribute an archive of a flat install tree which includes all dependencies.{n} The resulting archive does not include the `etc` directory or build dependencies.{n} Unlike a Lux tree, dependency conflicts are not supported/handled'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from dist" -f -a "bin" -d 'Compile a Lux project, including its dependencies, into a single binary,{n} which runs on systems that do not have Lua installed.{n} Projects with native Lua modules are not single binaries: the modules are{n} copied as shared libraries next to the output binary, and must be{n} shipped alongside it.{n} As with flat-archive, dependency conflicts are not supported/handled.{n} {n} The entrypoint is specified via the lux.toml\'s [run] field, e.g.: {n} {n} ```toml{n} [run]{n} args = ["src/main.lua"]{n} ```'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from path" -f -a "full" -d 'Generate an export statement for all paths (formatted as a shell command). [Default]'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from path" -f -a "lua" -d 'Generate a `LUA_PATH` expression for `lua` libraries in the lux tree. (not formatted as a shell command)'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from path" -f -a "c" -d 'Generate a `LUA_CPATH` expression for native `lib` libraries in the lux tree. (not formatted as a shell command)'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from path" -f -a "bin" -d 'Generate a `PATH` expression for `bin` executables in the lux tree. (not formatted as a shell command)'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from path" -f -a "init" -d 'Generate a `LUA_INIT` expression for the lux loader. (not formatted as a shell command)'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from util" -f -a "completion" -d 'Generate autocompletion scripts for the shell.{n} Example: `lx completion zsh > ~/.zsh/completions/_lx`'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from util" -f -a "man" -d 'Generate manpages'
complete -c lx -n "__fish_lx_using_subcommand help; and __fish_seen_subcommand_from util" -f -a "schema" -d 'Generate the JSON Schema for `lux.toml` or `config.toml`'
