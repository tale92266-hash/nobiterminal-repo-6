// This is marked as `test = true` and hence picked up by `./x miri`, but that would be too slow.
#![cfg(not(miri))]
#![allow(internal_features)]
#![feature(iter_next_chunk)]
#![feature(repr_simd)]
#![feature(slice_partition_dedup)]
#![feature(strict_provenance_lints)]
#![feature(test)]
#![deny(implicit_provenance_casts)]

extern crate test;

mod binary_heap;
mod btree;
mod io;
mod linked_list;
mod slice;
mod str;
mod string;
mod vec;
mod vec_deque;

/// Returns a `rand::Rng` seeded with a consistent seed.
///
/// This is done to avoid introducing nondeterminism in benchmark results.
fn bench_rng() -> rand_xorshift::XorShiftRng {
    const SEED: [u8; 16] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15];
    rand::SeedableRng::from_seed(SEED)
}
