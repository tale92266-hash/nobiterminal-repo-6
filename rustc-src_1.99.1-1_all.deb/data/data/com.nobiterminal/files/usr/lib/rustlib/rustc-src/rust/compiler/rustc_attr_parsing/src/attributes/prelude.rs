// data structures
#[doc(hidden)]
pub(super) use rustc_attr_ir::AttributeKind;
#[doc(hidden)]
pub(super) use rustc_attr_ir::target::{MethodKind, Target};
#[doc(hidden)]
pub(super) use rustc_span::{Ident, Span, Symbol, sym};
#[doc(hidden)]
pub(super) use thin_vec::ThinVec;

#[doc(hidden)]
pub(super) use crate::attributes::{
    AcceptMapping, AttributeParser, CombineAttributeParser, ConvertFn, NoArgsAttributeParser,
    OnDuplicate, SingleAttributeParser,
};
// contexts
#[doc(hidden)]
pub(super) use crate::context::{AcceptContext, FinalizeCheckContext, FinalizeContext};
#[doc(hidden)]
pub(super) use crate::parser::*;
// target checking
#[doc(hidden)]
pub(super) use crate::target_checking::Policy::{Allow, Error, Warn};
#[doc(hidden)]
pub(super) use crate::target_checking::{ALL_TARGETS, AllowedTargets};
#[doc(hidden)]
pub(super) use crate::unstable;
pub(super) use crate::{AttributeTemplate, template};
