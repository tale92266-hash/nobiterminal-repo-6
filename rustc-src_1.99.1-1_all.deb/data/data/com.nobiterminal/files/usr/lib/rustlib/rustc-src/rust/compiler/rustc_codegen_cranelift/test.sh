#!/data/data/com.nobiterminal/files/usr/bin/sh
exec ./y.sh test "$@"
