# This file will be patched by setup.py
# The __version__ should be set to the branch name
# Leave __baseline__ set to unknown to enable setting commit-hash
# (e.g. "develop" or "1.2.x")

# You MUST use double quotes (so " and not ')
# Do not forget to update the appdata file for every major release!

__version__ = "5.1.3"
__baseline__ = "a647f73426cb70ad60ae7964b96c2d5e939b4727"
