#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SuiteSparse::COLAMD_static" for configuration "Release"
set_property(TARGET SuiteSparse::COLAMD_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SuiteSparse::COLAMD_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libcolamd.a"
  )

list(APPEND _cmake_import_check_targets SuiteSparse::COLAMD_static )
list(APPEND _cmake_import_check_files_for_SuiteSparse::COLAMD_static "/data/data/com.nobiterminal/files/usr/lib/libcolamd.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
