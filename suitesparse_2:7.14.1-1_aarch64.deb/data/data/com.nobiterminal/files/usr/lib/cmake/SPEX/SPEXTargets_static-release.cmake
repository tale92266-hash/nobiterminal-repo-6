#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SuiteSparse::SPEX_static" for configuration "Release"
set_property(TARGET SuiteSparse::SPEX_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SuiteSparse::SPEX_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libspex.a"
  )

list(APPEND _cmake_import_check_targets SuiteSparse::SPEX_static )
list(APPEND _cmake_import_check_files_for_SuiteSparse::SPEX_static "/data/data/com.nobiterminal/files/usr/lib/libspex.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
