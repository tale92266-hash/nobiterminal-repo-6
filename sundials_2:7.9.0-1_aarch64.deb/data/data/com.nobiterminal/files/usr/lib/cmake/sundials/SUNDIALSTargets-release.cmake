#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SUNDIALS::core_static" for configuration "Release"
set_property(TARGET SUNDIALS::core_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::core_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_core.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::core_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::core_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_core.a" )

# Import target "SUNDIALS::core_shared" for configuration "Release"
set_property(TARGET SUNDIALS::core_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::core_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_core.so.7.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_core.so.7"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::core_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::core_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_core.so.7.9.0" )

# Import target "SUNDIALS::nvecserial_static" for configuration "Release"
set_property(TARGET SUNDIALS::nvecserial_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::nvecserial_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecserial.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::nvecserial_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::nvecserial_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecserial.a" )

# Import target "SUNDIALS::nvecserial_shared" for configuration "Release"
set_property(TARGET SUNDIALS::nvecserial_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::nvecserial_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecserial.so.7.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_nvecserial.so.7"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::nvecserial_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::nvecserial_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecserial.so.7.9.0" )

# Import target "SUNDIALS::nvecmanyvector_static" for configuration "Release"
set_property(TARGET SUNDIALS::nvecmanyvector_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::nvecmanyvector_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecmanyvector.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::nvecmanyvector_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::nvecmanyvector_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecmanyvector.a" )

# Import target "SUNDIALS::nvecmanyvector_shared" for configuration "Release"
set_property(TARGET SUNDIALS::nvecmanyvector_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::nvecmanyvector_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecmanyvector.so.7.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_nvecmanyvector.so.7"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::nvecmanyvector_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::nvecmanyvector_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecmanyvector.so.7.9.0" )

# Import target "SUNDIALS::nvecopenmp_static" for configuration "Release"
set_property(TARGET SUNDIALS::nvecopenmp_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::nvecopenmp_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecopenmp.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::nvecopenmp_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::nvecopenmp_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecopenmp.a" )

# Import target "SUNDIALS::nvecopenmp_shared" for configuration "Release"
set_property(TARGET SUNDIALS::nvecopenmp_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::nvecopenmp_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecopenmp.so.7.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_nvecopenmp.so.7"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::nvecopenmp_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::nvecopenmp_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecopenmp.so.7.9.0" )

# Import target "SUNDIALS::nvecpthreads_static" for configuration "Release"
set_property(TARGET SUNDIALS::nvecpthreads_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::nvecpthreads_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecpthreads.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::nvecpthreads_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::nvecpthreads_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecpthreads.a" )

# Import target "SUNDIALS::nvecpthreads_shared" for configuration "Release"
set_property(TARGET SUNDIALS::nvecpthreads_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::nvecpthreads_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecpthreads.so.7.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_nvecpthreads.so.7"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::nvecpthreads_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::nvecpthreads_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_nvecpthreads.so.7.9.0" )

# Import target "SUNDIALS::sunmatrixband_static" for configuration "Release"
set_property(TARGET SUNDIALS::sunmatrixband_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunmatrixband_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunmatrixband.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunmatrixband_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunmatrixband_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunmatrixband.a" )

# Import target "SUNDIALS::sunmatrixband_shared" for configuration "Release"
set_property(TARGET SUNDIALS::sunmatrixband_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunmatrixband_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunmatrixband.so.5.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_sunmatrixband.so.5"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunmatrixband_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunmatrixband_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunmatrixband.so.5.9.0" )

# Import target "SUNDIALS::sunmatrixdense_static" for configuration "Release"
set_property(TARGET SUNDIALS::sunmatrixdense_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunmatrixdense_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunmatrixdense.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunmatrixdense_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunmatrixdense_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunmatrixdense.a" )

# Import target "SUNDIALS::sunmatrixdense_shared" for configuration "Release"
set_property(TARGET SUNDIALS::sunmatrixdense_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunmatrixdense_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunmatrixdense.so.5.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_sunmatrixdense.so.5"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunmatrixdense_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunmatrixdense_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunmatrixdense.so.5.9.0" )

# Import target "SUNDIALS::sunmatrixsparse_static" for configuration "Release"
set_property(TARGET SUNDIALS::sunmatrixsparse_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunmatrixsparse_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunmatrixsparse.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunmatrixsparse_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunmatrixsparse_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunmatrixsparse.a" )

# Import target "SUNDIALS::sunmatrixsparse_shared" for configuration "Release"
set_property(TARGET SUNDIALS::sunmatrixsparse_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunmatrixsparse_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunmatrixsparse.so.5.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_sunmatrixsparse.so.5"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunmatrixsparse_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunmatrixsparse_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunmatrixsparse.so.5.9.0" )

# Import target "SUNDIALS::sunlinsolband_static" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsolband_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsolband_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolband.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsolband_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsolband_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolband.a" )

# Import target "SUNDIALS::sunlinsolband_shared" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsolband_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsolband_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolband.so.5.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_sunlinsolband.so.5"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsolband_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsolband_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolband.so.5.9.0" )

# Import target "SUNDIALS::sunlinsoldense_static" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsoldense_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsoldense_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsoldense.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsoldense_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsoldense_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsoldense.a" )

# Import target "SUNDIALS::sunlinsoldense_shared" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsoldense_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsoldense_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsoldense.so.5.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_sunlinsoldense.so.5"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsoldense_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsoldense_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsoldense.so.5.9.0" )

# Import target "SUNDIALS::sunlinsolpcg_static" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsolpcg_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsolpcg_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolpcg.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsolpcg_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsolpcg_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolpcg.a" )

# Import target "SUNDIALS::sunlinsolpcg_shared" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsolpcg_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsolpcg_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolpcg.so.5.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_sunlinsolpcg.so.5"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsolpcg_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsolpcg_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolpcg.so.5.9.0" )

# Import target "SUNDIALS::sunlinsolspbcgs_static" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsolspbcgs_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsolspbcgs_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolspbcgs.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsolspbcgs_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsolspbcgs_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolspbcgs.a" )

# Import target "SUNDIALS::sunlinsolspbcgs_shared" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsolspbcgs_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsolspbcgs_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolspbcgs.so.5.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_sunlinsolspbcgs.so.5"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsolspbcgs_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsolspbcgs_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolspbcgs.so.5.9.0" )

# Import target "SUNDIALS::sunlinsolspfgmr_static" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsolspfgmr_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsolspfgmr_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolspfgmr.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsolspfgmr_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsolspfgmr_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolspfgmr.a" )

# Import target "SUNDIALS::sunlinsolspfgmr_shared" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsolspfgmr_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsolspfgmr_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolspfgmr.so.5.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_sunlinsolspfgmr.so.5"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsolspfgmr_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsolspfgmr_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolspfgmr.so.5.9.0" )

# Import target "SUNDIALS::sunlinsolspgmr_static" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsolspgmr_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsolspgmr_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolspgmr.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsolspgmr_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsolspgmr_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolspgmr.a" )

# Import target "SUNDIALS::sunlinsolspgmr_shared" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsolspgmr_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsolspgmr_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolspgmr.so.5.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_sunlinsolspgmr.so.5"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsolspgmr_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsolspgmr_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolspgmr.so.5.9.0" )

# Import target "SUNDIALS::sunlinsolsptfqmr_static" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsolsptfqmr_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsolsptfqmr_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolsptfqmr.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsolsptfqmr_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsolsptfqmr_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolsptfqmr.a" )

# Import target "SUNDIALS::sunlinsolsptfqmr_shared" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsolsptfqmr_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsolsptfqmr_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolsptfqmr.so.5.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_sunlinsolsptfqmr.so.5"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsolsptfqmr_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsolsptfqmr_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolsptfqmr.so.5.9.0" )

# Import target "SUNDIALS::sunlinsolklu_static" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsolklu_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsolklu_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolklu.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsolklu_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsolklu_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolklu.a" )

# Import target "SUNDIALS::sunlinsolklu_shared" for configuration "Release"
set_property(TARGET SUNDIALS::sunlinsolklu_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunlinsolklu_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolklu.so.5.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_sunlinsolklu.so.5"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunlinsolklu_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunlinsolklu_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunlinsolklu.so.5.9.0" )

# Import target "SUNDIALS::sunnonlinsolnewton_static" for configuration "Release"
set_property(TARGET SUNDIALS::sunnonlinsolnewton_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunnonlinsolnewton_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunnonlinsolnewton.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunnonlinsolnewton_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunnonlinsolnewton_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunnonlinsolnewton.a" )

# Import target "SUNDIALS::sunnonlinsolnewton_shared" for configuration "Release"
set_property(TARGET SUNDIALS::sunnonlinsolnewton_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunnonlinsolnewton_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunnonlinsolnewton.so.4.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_sunnonlinsolnewton.so.4"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunnonlinsolnewton_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunnonlinsolnewton_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunnonlinsolnewton.so.4.9.0" )

# Import target "SUNDIALS::sunnonlinsolfixedpoint_static" for configuration "Release"
set_property(TARGET SUNDIALS::sunnonlinsolfixedpoint_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunnonlinsolfixedpoint_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunnonlinsolfixedpoint.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunnonlinsolfixedpoint_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunnonlinsolfixedpoint_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunnonlinsolfixedpoint.a" )

# Import target "SUNDIALS::sunnonlinsolfixedpoint_shared" for configuration "Release"
set_property(TARGET SUNDIALS::sunnonlinsolfixedpoint_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunnonlinsolfixedpoint_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunnonlinsolfixedpoint.so.4.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_sunnonlinsolfixedpoint.so.4"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunnonlinsolfixedpoint_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunnonlinsolfixedpoint_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunnonlinsolfixedpoint.so.4.9.0" )

# Import target "SUNDIALS::sunnonlinsolauto_static" for configuration "Release"
set_property(TARGET SUNDIALS::sunnonlinsolauto_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunnonlinsolauto_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunnonlinsolauto.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunnonlinsolauto_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunnonlinsolauto_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunnonlinsolauto.a" )

# Import target "SUNDIALS::sunnonlinsolauto_shared" for configuration "Release"
set_property(TARGET SUNDIALS::sunnonlinsolauto_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sunnonlinsolauto_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunnonlinsolauto.so.4.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_sunnonlinsolauto.so.4"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sunnonlinsolauto_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sunnonlinsolauto_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_sunnonlinsolauto.so.4.9.0" )

# Import target "SUNDIALS::sundomeigestpower_static" for configuration "Release"
set_property(TARGET SUNDIALS::sundomeigestpower_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sundomeigestpower_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sundomeigestpower.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sundomeigestpower_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sundomeigestpower_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_sundomeigestpower.a" )

# Import target "SUNDIALS::sundomeigestpower_shared" for configuration "Release"
set_property(TARGET SUNDIALS::sundomeigestpower_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::sundomeigestpower_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_sundomeigestpower.so.1.4.0"
  IMPORTED_SONAME_RELEASE "libsundials_sundomeigestpower.so.1"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::sundomeigestpower_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::sundomeigestpower_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_sundomeigestpower.so.1.4.0" )

# Import target "SUNDIALS::arkode_static" for configuration "Release"
set_property(TARGET SUNDIALS::arkode_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::arkode_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_arkode.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::arkode_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::arkode_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_arkode.a" )

# Import target "SUNDIALS::arkode_shared" for configuration "Release"
set_property(TARGET SUNDIALS::arkode_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::arkode_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_arkode.so.6.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_arkode.so.6"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::arkode_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::arkode_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_arkode.so.6.9.0" )

# Import target "SUNDIALS::cvode_static" for configuration "Release"
set_property(TARGET SUNDIALS::cvode_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::cvode_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_cvode.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::cvode_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::cvode_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_cvode.a" )

# Import target "SUNDIALS::cvode_shared" for configuration "Release"
set_property(TARGET SUNDIALS::cvode_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::cvode_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_cvode.so.7.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_cvode.so.7"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::cvode_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::cvode_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_cvode.so.7.9.0" )

# Import target "SUNDIALS::cvodes_static" for configuration "Release"
set_property(TARGET SUNDIALS::cvodes_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::cvodes_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_cvodes.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::cvodes_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::cvodes_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_cvodes.a" )

# Import target "SUNDIALS::cvodes_shared" for configuration "Release"
set_property(TARGET SUNDIALS::cvodes_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::cvodes_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_cvodes.so.7.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_cvodes.so.7"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::cvodes_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::cvodes_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_cvodes.so.7.9.0" )

# Import target "SUNDIALS::ida_static" for configuration "Release"
set_property(TARGET SUNDIALS::ida_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::ida_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_ida.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::ida_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::ida_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_ida.a" )

# Import target "SUNDIALS::ida_shared" for configuration "Release"
set_property(TARGET SUNDIALS::ida_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::ida_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_ida.so.7.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_ida.so.7"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::ida_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::ida_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_ida.so.7.9.0" )

# Import target "SUNDIALS::idas_static" for configuration "Release"
set_property(TARGET SUNDIALS::idas_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::idas_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_idas.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::idas_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::idas_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_idas.a" )

# Import target "SUNDIALS::idas_shared" for configuration "Release"
set_property(TARGET SUNDIALS::idas_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::idas_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_idas.so.6.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_idas.so.6"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::idas_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::idas_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_idas.so.6.9.0" )

# Import target "SUNDIALS::kinsol_static" for configuration "Release"
set_property(TARGET SUNDIALS::kinsol_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::kinsol_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_kinsol.a"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::kinsol_static )
list(APPEND _cmake_import_check_files_for_SUNDIALS::kinsol_static "/data/data/com.nobiterminal/files/usr/lib/libsundials_kinsol.a" )

# Import target "SUNDIALS::kinsol_shared" for configuration "Release"
set_property(TARGET SUNDIALS::kinsol_shared APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SUNDIALS::kinsol_shared PROPERTIES
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libsundials_kinsol.so.7.9.0"
  IMPORTED_SONAME_RELEASE "libsundials_kinsol.so.7"
  )

list(APPEND _cmake_import_check_targets SUNDIALS::kinsol_shared )
list(APPEND _cmake_import_check_files_for_SUNDIALS::kinsol_shared "/data/data/com.nobiterminal/files/usr/lib/libsundials_kinsol.so.7.9.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
