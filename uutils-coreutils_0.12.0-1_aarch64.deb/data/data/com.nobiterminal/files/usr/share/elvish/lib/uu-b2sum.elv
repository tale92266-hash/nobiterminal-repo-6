
use builtin;
use str;

set edit:completion:arg-completer[uu-b2sum] = {|@words|
    fn spaces {|n|
        builtin:repeat $n ' ' | str:join ''
    }
    fn cand {|text desc|
        edit:complex-candidate $text &display=$text' '(spaces (- 14 (wcswidth $text)))$desc
    }
    var command = 'uu-b2sum'
    for word $words[1..-1] {
        if (str:has-prefix $word '-') {
            break
        }
        set command = $command';'$word
    }
    var completions = [
        &'uu-b2sum'= {
            cand -l 'digest length in bits; must not exceed the max size and must be a multiple of 8 for blake2b; must be 224, 256, 384, or 512 for sha2 or sha3'
            cand --length 'digest length in bits; must not exceed the max size and must be a multiple of 8 for blake2b; must be 224, 256, 384, or 512 for sha2 or sha3'
            cand -b 'b'
            cand --binary 'binary'
            cand -c 'read checksums from the FILEs and check them'
            cand --check 'read checksums from the FILEs and check them'
            cand -w 'warn about improperly formatted checksum lines'
            cand --warn 'warn about improperly formatted checksum lines'
            cand --status 'don''t output anything, status code shows success'
            cand --quiet 'don''t print OK for each successfully verified file'
            cand --ignore-missing 'don''t fail or report status for missing files'
            cand --strict 'exit non-zero for improperly formatted checksum lines'
            cand --tag 'create a BSD style checksum'
            cand -t 't'
            cand --text 'text'
            cand -z 'end each output line with NUL, not newline, and disable file name escaping'
            cand --zero 'end each output line with NUL, not newline, and disable file name escaping'
            cand -h 'Print help'
            cand --help 'Print help'
            cand -V 'Print version'
            cand --version 'Print version'
        }
    ]
    $completions[$command]
}
