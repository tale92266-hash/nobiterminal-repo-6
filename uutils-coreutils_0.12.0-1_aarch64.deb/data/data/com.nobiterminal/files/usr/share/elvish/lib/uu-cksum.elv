
use builtin;
use str;

set edit:completion:arg-completer[uu-cksum] = {|@words|
    fn spaces {|n|
        builtin:repeat $n ' ' | str:join ''
    }
    fn cand {|text desc|
        edit:complex-candidate $text &display=$text' '(spaces (- 14 (wcswidth $text)))$desc
    }
    var command = 'uu-cksum'
    for word $words[1..-1] {
        if (str:has-prefix $word '-') {
            break
        }
        set command = $command';'$word
    }
    var completions = [
        &'uu-cksum'= {
            cand -a 'select the digest type to use. See DIGEST below'
            cand --algorithm 'select the digest type to use. See DIGEST below'
            cand -l 'digest length in bits; must not exceed the max size and must be a multiple of 8 for blake2b; must be 224, 256, 384, or 512 for sha2 or sha3'
            cand --length 'digest length in bits; must not exceed the max size and must be a multiple of 8 for blake2b; must be 224, 256, 384, or 512 for sha2 or sha3'
            cand --untagged 'create a reversed style checksum, without digest type'
            cand --tag 'create a BSD style checksum (default)'
            cand --raw 'emit a raw binary digest, not hexadecimal'
            cand -c 'read checksums from the FILEs and check them'
            cand --check 'read checksums from the FILEs and check them'
            cand -w 'warn about improperly formatted checksum lines'
            cand --warn 'warn about improperly formatted checksum lines'
            cand --status 'don''t output anything, status code shows success'
            cand --quiet 'don''t print OK for each successfully verified file'
            cand --ignore-missing 'don''t fail or report status for missing files'
            cand --strict 'exit non-zero for improperly formatted checksum lines'
            cand --base64 'emit base64-encoded digests, not hexadecimal'
            cand -t 't'
            cand --text 'text'
            cand -b 'b'
            cand --binary 'binary'
            cand -z 'end each output line with NUL, not newline, and disable file name escaping'
            cand --zero 'end each output line with NUL, not newline, and disable file name escaping'
            cand --debug 'print CPU hardware capability detection info used by cksum'
            cand -h 'Print help'
            cand --help 'Print help'
            cand -V 'Print version'
            cand --version 'Print version'
        }
    ]
    $completions[$command]
}
