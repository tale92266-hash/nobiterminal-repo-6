
use builtin;
use str;

set edit:completion:arg-completer[uu-coreutils] = {|@words|
    fn spaces {|n|
        builtin:repeat $n ' ' | str:join ''
    }
    fn cand {|text desc|
        edit:complex-candidate $text &display=$text' '(spaces (- 14 (wcswidth $text)))$desc
    }
    var command = 'uu-coreutils'
    for word $words[1..-1] {
        if (str:has-prefix $word '-') {
            break
        }
        set command = $command';'$word
    }
    var completions = [
        &'uu-coreutils'= {
            cand -h 'Print help'
            cand --help 'Print help'
            cand [ 'test-about'
            cand arch 'arch-about'
            cand b2sum 'b2sum-about'
            cand base32 'base32-about'
            cand base64 'base64-about'
            cand basename 'basename-about'
            cand basenc 'basenc-about'
            cand cat 'cat-about'
            cand cksum 'cksum-about'
            cand comm 'comm-about'
            cand cp 'cp-about'
            cand csplit 'csplit-about'
            cand cut 'cut-about'
            cand date 'date-about'
            cand dd 'dd-about'
            cand dir 'dir-about'
            cand dircolors 'dircolors-about'
            cand dirname 'dirname-about'
            cand echo 'echo-about'
            cand expand 'expand-about'
            cand expr 'expr-about'
            cand factor 'factor-about'
            cand false 'false-about'
            cand fmt 'fmt-about'
            cand fold 'fold-about'
            cand head 'head-about'
            cand hostid 'hostid-about'
            cand join 'join-about'
            cand link 'link-about'
            cand ln 'ln-about'
            cand ls 'ls-about'
            cand md5sum 'md5sum-about'
            cand mkdir 'mkdir-about'
            cand mktemp 'mktemp-about'
            cand mv 'mv-about'
            cand nice 'nice-about'
            cand nl 'nl-about'
            cand numfmt 'numfmt-about'
            cand od 'od-about'
            cand paste 'paste-about'
            cand pathchk 'pathchk-about'
            cand pr 'pr-about'
            cand printenv 'printenv-about'
            cand printf 'printf-about'
            cand ptx 'ptx-about'
            cand pwd 'pwd-about'
            cand readlink 'readlink-about'
            cand realpath 'realpath-about'
            cand rm 'rm-about'
            cand rmdir 'rmdir-about'
            cand seq 'seq-about'
            cand sha1sum 'sha1sum-about'
            cand sha224sum 'sha224sum-about'
            cand sha256sum 'sha256sum-about'
            cand sha384sum 'sha384sum-about'
            cand sha512sum 'sha512sum-about'
            cand shred 'shred-about'
            cand shuf 'shuf-about'
            cand sleep 'sleep-about'
            cand sort 'sort-about'
            cand split 'split-about'
            cand sum 'sum-about'
            cand tail 'tail-about'
            cand tee 'tee-about'
            cand test 'test-about'
            cand touch 'touch-about'
            cand tr 'tr-about'
            cand true 'true-about'
            cand truncate 'truncate-about'
            cand tsort 'tsort-about'
            cand tty 'tty-about'
            cand uname 'uname-about'
            cand unexpand 'unexpand-about'
            cand uniq 'uniq-about'
            cand unlink 'unlink-about'
            cand vdir 'vdir-about'
            cand wc 'wc-about'
            cand yes 'yes-about'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'uu-coreutils;['= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;arch'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;b2sum'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;base32'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;base64'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;basename'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;basenc'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;cat'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;cksum'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;comm'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;cp'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;csplit'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;cut'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;date'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;dd'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;dir'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;dircolors'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;dirname'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;echo'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;expand'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;expr'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;factor'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;false'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;fmt'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;fold'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;head'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;hostid'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;join'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;link'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;ln'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;ls'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;md5sum'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;mkdir'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;mktemp'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;mv'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;nice'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;nl'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;numfmt'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;od'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;paste'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;pathchk'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;pr'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;printenv'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;printf'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;ptx'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;pwd'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;readlink'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;realpath'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;rm'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;rmdir'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;seq'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;sha1sum'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;sha224sum'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;sha256sum'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;sha384sum'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;sha512sum'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;shred'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;shuf'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;sleep'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;sort'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;split'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;sum'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;tail'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;tee'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;test'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;touch'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;tr'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;true'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;truncate'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;tsort'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;tty'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;uname'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;unexpand'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;uniq'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;unlink'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;vdir'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;wc'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;yes'= {
            cand -h 'Print help'
            cand --help 'Print help'
        }
        &'uu-coreutils;help'= {
            cand [ 'test-about'
            cand arch 'arch-about'
            cand b2sum 'b2sum-about'
            cand base32 'base32-about'
            cand base64 'base64-about'
            cand basename 'basename-about'
            cand basenc 'basenc-about'
            cand cat 'cat-about'
            cand cksum 'cksum-about'
            cand comm 'comm-about'
            cand cp 'cp-about'
            cand csplit 'csplit-about'
            cand cut 'cut-about'
            cand date 'date-about'
            cand dd 'dd-about'
            cand dir 'dir-about'
            cand dircolors 'dircolors-about'
            cand dirname 'dirname-about'
            cand echo 'echo-about'
            cand expand 'expand-about'
            cand expr 'expr-about'
            cand factor 'factor-about'
            cand false 'false-about'
            cand fmt 'fmt-about'
            cand fold 'fold-about'
            cand head 'head-about'
            cand hostid 'hostid-about'
            cand join 'join-about'
            cand link 'link-about'
            cand ln 'ln-about'
            cand ls 'ls-about'
            cand md5sum 'md5sum-about'
            cand mkdir 'mkdir-about'
            cand mktemp 'mktemp-about'
            cand mv 'mv-about'
            cand nice 'nice-about'
            cand nl 'nl-about'
            cand numfmt 'numfmt-about'
            cand od 'od-about'
            cand paste 'paste-about'
            cand pathchk 'pathchk-about'
            cand pr 'pr-about'
            cand printenv 'printenv-about'
            cand printf 'printf-about'
            cand ptx 'ptx-about'
            cand pwd 'pwd-about'
            cand readlink 'readlink-about'
            cand realpath 'realpath-about'
            cand rm 'rm-about'
            cand rmdir 'rmdir-about'
            cand seq 'seq-about'
            cand sha1sum 'sha1sum-about'
            cand sha224sum 'sha224sum-about'
            cand sha256sum 'sha256sum-about'
            cand sha384sum 'sha384sum-about'
            cand sha512sum 'sha512sum-about'
            cand shred 'shred-about'
            cand shuf 'shuf-about'
            cand sleep 'sleep-about'
            cand sort 'sort-about'
            cand split 'split-about'
            cand sum 'sum-about'
            cand tail 'tail-about'
            cand tee 'tee-about'
            cand test 'test-about'
            cand touch 'touch-about'
            cand tr 'tr-about'
            cand true 'true-about'
            cand truncate 'truncate-about'
            cand tsort 'tsort-about'
            cand tty 'tty-about'
            cand uname 'uname-about'
            cand unexpand 'unexpand-about'
            cand uniq 'uniq-about'
            cand unlink 'unlink-about'
            cand vdir 'vdir-about'
            cand wc 'wc-about'
            cand yes 'yes-about'
            cand help 'Print this message or the help of the given subcommand(s)'
        }
        &'uu-coreutils;help;['= {
        }
        &'uu-coreutils;help;arch'= {
        }
        &'uu-coreutils;help;b2sum'= {
        }
        &'uu-coreutils;help;base32'= {
        }
        &'uu-coreutils;help;base64'= {
        }
        &'uu-coreutils;help;basename'= {
        }
        &'uu-coreutils;help;basenc'= {
        }
        &'uu-coreutils;help;cat'= {
        }
        &'uu-coreutils;help;cksum'= {
        }
        &'uu-coreutils;help;comm'= {
        }
        &'uu-coreutils;help;cp'= {
        }
        &'uu-coreutils;help;csplit'= {
        }
        &'uu-coreutils;help;cut'= {
        }
        &'uu-coreutils;help;date'= {
        }
        &'uu-coreutils;help;dd'= {
        }
        &'uu-coreutils;help;dir'= {
        }
        &'uu-coreutils;help;dircolors'= {
        }
        &'uu-coreutils;help;dirname'= {
        }
        &'uu-coreutils;help;echo'= {
        }
        &'uu-coreutils;help;expand'= {
        }
        &'uu-coreutils;help;expr'= {
        }
        &'uu-coreutils;help;factor'= {
        }
        &'uu-coreutils;help;false'= {
        }
        &'uu-coreutils;help;fmt'= {
        }
        &'uu-coreutils;help;fold'= {
        }
        &'uu-coreutils;help;head'= {
        }
        &'uu-coreutils;help;hostid'= {
        }
        &'uu-coreutils;help;join'= {
        }
        &'uu-coreutils;help;link'= {
        }
        &'uu-coreutils;help;ln'= {
        }
        &'uu-coreutils;help;ls'= {
        }
        &'uu-coreutils;help;md5sum'= {
        }
        &'uu-coreutils;help;mkdir'= {
        }
        &'uu-coreutils;help;mktemp'= {
        }
        &'uu-coreutils;help;mv'= {
        }
        &'uu-coreutils;help;nice'= {
        }
        &'uu-coreutils;help;nl'= {
        }
        &'uu-coreutils;help;numfmt'= {
        }
        &'uu-coreutils;help;od'= {
        }
        &'uu-coreutils;help;paste'= {
        }
        &'uu-coreutils;help;pathchk'= {
        }
        &'uu-coreutils;help;pr'= {
        }
        &'uu-coreutils;help;printenv'= {
        }
        &'uu-coreutils;help;printf'= {
        }
        &'uu-coreutils;help;ptx'= {
        }
        &'uu-coreutils;help;pwd'= {
        }
        &'uu-coreutils;help;readlink'= {
        }
        &'uu-coreutils;help;realpath'= {
        }
        &'uu-coreutils;help;rm'= {
        }
        &'uu-coreutils;help;rmdir'= {
        }
        &'uu-coreutils;help;seq'= {
        }
        &'uu-coreutils;help;sha1sum'= {
        }
        &'uu-coreutils;help;sha224sum'= {
        }
        &'uu-coreutils;help;sha256sum'= {
        }
        &'uu-coreutils;help;sha384sum'= {
        }
        &'uu-coreutils;help;sha512sum'= {
        }
        &'uu-coreutils;help;shred'= {
        }
        &'uu-coreutils;help;shuf'= {
        }
        &'uu-coreutils;help;sleep'= {
        }
        &'uu-coreutils;help;sort'= {
        }
        &'uu-coreutils;help;split'= {
        }
        &'uu-coreutils;help;sum'= {
        }
        &'uu-coreutils;help;tail'= {
        }
        &'uu-coreutils;help;tee'= {
        }
        &'uu-coreutils;help;test'= {
        }
        &'uu-coreutils;help;touch'= {
        }
        &'uu-coreutils;help;tr'= {
        }
        &'uu-coreutils;help;true'= {
        }
        &'uu-coreutils;help;truncate'= {
        }
        &'uu-coreutils;help;tsort'= {
        }
        &'uu-coreutils;help;tty'= {
        }
        &'uu-coreutils;help;uname'= {
        }
        &'uu-coreutils;help;unexpand'= {
        }
        &'uu-coreutils;help;uniq'= {
        }
        &'uu-coreutils;help;unlink'= {
        }
        &'uu-coreutils;help;vdir'= {
        }
        &'uu-coreutils;help;wc'= {
        }
        &'uu-coreutils;help;yes'= {
        }
        &'uu-coreutils;help;help'= {
        }
    ]
    $completions[$command]
}
