
use builtin;
use str;

set edit:completion:arg-completer[uu-cut] = {|@words|
    fn spaces {|n|
        builtin:repeat $n ' ' | str:join ''
    }
    fn cand {|text desc|
        edit:complex-candidate $text &display=$text' '(spaces (- 14 (wcswidth $text)))$desc
    }
    var command = 'uu-cut'
    for word $words[1..-1] {
        if (str:has-prefix $word '-') {
            break
        }
        set command = $command';'$word
    }
    var completions = [
        &'uu-cut'= {
            cand -b 'extract bytes listed in LIST'
            cand --bytes 'extract bytes listed in LIST'
            cand -c 'extract characters listed in LIST'
            cand --characters 'extract characters listed in LIST'
            cand -d 'use DELIM as field separator (default: Tab)'
            cand --delimiter 'use DELIM as field separator (default: Tab)'
            cand -w 'use any whitespace (Space/Tab) as delimiter; ignore leading and trailing blanks with ''trimmed'''
            cand --whitespace-delimited 'use any whitespace (Space/Tab) as delimiter; ignore leading and trailing blanks with ''trimmed'''
            cand -f 'extract fields listed in LIST'
            cand --fields 'extract fields listed in LIST'
            cand -F 'like -f, but merge adjacent delimiters; the delimiter defaults to whitespace and the output delimiter to a space'
            cand -O 'replace input delimiter with NEW_DELIM in output'
            cand --output-delimiter 'replace input delimiter with NEW_DELIM in output'
            cand --complement 'invert selection: print all columns except the specified ones'
            cand -s 'suppress lines that do not contain the delimiter'
            cand --only-delimited 'suppress lines that do not contain the delimiter'
            cand -z 'use NULL (\0) instead of newline as line terminator'
            cand --zero-terminated 'use NULL (\0) instead of newline as line terminator'
            cand -n 'with -b, do not output partial multi-byte characters'
            cand --no-partial 'with -b, do not output partial multi-byte characters'
            cand -h 'Print help'
            cand --help 'Print help'
            cand -V 'Print version'
            cand --version 'Print version'
        }
    ]
    $completions[$command]
}
