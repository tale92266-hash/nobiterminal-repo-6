
use builtin;
use str;

set edit:completion:arg-completer[uu-sha224sum] = {|@words|
    fn spaces {|n|
        builtin:repeat $n ' ' | str:join ''
    }
    fn cand {|text desc|
        edit:complex-candidate $text &display=$text' '(spaces (- 14 (wcswidth $text)))$desc
    }
    var command = 'uu-sha224sum'
    for word $words[1..-1] {
        if (str:has-prefix $word '-') {
            break
        }
        set command = $command';'$word
    }
    var completions = [
        &'uu-sha224sum'= {
            cand -b 'b'
            cand --binary 'binary'
            cand -c 'read checksums from the FILEs and check them'
            cand --check 'read checksums from the FILEs and check them'
            cand -w 'warn about improperly formatted checksum lines'
            cand --warn 'warn about improperly formatted checksum lines'
            cand --status 'don''t output anything, status code shows success'
            cand --quiet 'don''t print OK for each successfully verified file'
            cand --ignore-missing 'don''t fail or report status for missing files'
            cand --strict 'exit non-zero for improperly formatted checksum lines'
            cand --tag 'create a BSD style checksum'
            cand -t 't'
            cand --text 'text'
            cand -z 'end each output line with NUL, not newline, and disable file name escaping'
            cand --zero 'end each output line with NUL, not newline, and disable file name escaping'
            cand -h 'Print help'
            cand --help 'Print help'
            cand -V 'Print version'
            cand --version 'Print version'
        }
    ]
    $completions[$command]
}
