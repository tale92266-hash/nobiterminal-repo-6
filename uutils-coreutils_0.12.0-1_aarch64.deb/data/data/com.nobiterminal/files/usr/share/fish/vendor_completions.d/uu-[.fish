complete -c uu-[ -s h -l help -d 'Print help'
complete -c uu-[ -s V -l version -d 'Print version'
