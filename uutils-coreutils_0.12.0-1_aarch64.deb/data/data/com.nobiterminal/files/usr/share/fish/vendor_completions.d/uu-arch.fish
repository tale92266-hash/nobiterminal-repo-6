complete -c uu-arch -s h -l help -d 'Print help'
complete -c uu-arch -s V -l version -d 'Print version'
