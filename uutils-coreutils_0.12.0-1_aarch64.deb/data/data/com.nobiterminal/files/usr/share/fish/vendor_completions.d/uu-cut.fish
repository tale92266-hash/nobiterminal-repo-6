complete -c uu-cut -s b -l bytes -d 'extract bytes listed in LIST' -r
complete -c uu-cut -s c -l characters -d 'extract characters listed in LIST' -r
complete -c uu-cut -s d -l delimiter -d 'use DELIM as field separator (default: Tab)' -r
complete -c uu-cut -s w -l whitespace-delimited -d 'use any whitespace (Space/Tab) as delimiter; ignore leading and trailing blanks with \'trimmed\'' -r -f -a "trimmed\t''"
complete -c uu-cut -s f -l fields -d 'extract fields listed in LIST' -r
complete -c uu-cut -s F -d 'like -f, but merge adjacent delimiters; the delimiter defaults to whitespace and the output delimiter to a space' -r
complete -c uu-cut -s O -l output-delimiter -d 'replace input delimiter with NEW_DELIM in output' -r
complete -c uu-cut -l complement -d 'invert selection: print all columns except the specified ones'
complete -c uu-cut -s s -l only-delimited -d 'suppress lines that do not contain the delimiter'
complete -c uu-cut -s z -l zero-terminated -d 'use NULL (\\0) instead of newline as line terminator'
complete -c uu-cut -s n -l no-partial -d 'with -b, do not output partial multi-byte characters'
complete -c uu-cut -s h -l help -d 'Print help'
complete -c uu-cut -s V -l version -d 'Print version'
