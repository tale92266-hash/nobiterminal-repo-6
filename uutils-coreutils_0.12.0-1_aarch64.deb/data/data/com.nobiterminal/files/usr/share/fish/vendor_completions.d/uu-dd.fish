complete -c uu-dd -s h -l help -d 'Print help'
complete -c uu-dd -s V -l version -d 'Print version'
