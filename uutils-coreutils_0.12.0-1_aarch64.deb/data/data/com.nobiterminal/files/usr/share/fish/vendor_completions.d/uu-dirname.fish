complete -c uu-dirname -s z -l zero -d 'separate output with NUL rather than newline'
complete -c uu-dirname -s h -l help -d 'Print help'
complete -c uu-dirname -s V -l version -d 'Print version'
