complete -c uu-expand -s t -l tabs -d 'have tabs N characters apart, not 8 or use comma separated list of explicit tab positions' -r
complete -c uu-expand -s i -l initial -d 'do not convert tabs after non blanks'
complete -c uu-expand -s U -l no-utf8 -d 'interpret input file as 8-bit ASCII rather than UTF-8'
complete -c uu-expand -s h -l help -d 'Print help'
complete -c uu-expand -s V -l version -d 'Print version'
