complete -c uu-expr -l version -d 'output version information and exit'
complete -c uu-expr -l help -d 'display this help and exit'
