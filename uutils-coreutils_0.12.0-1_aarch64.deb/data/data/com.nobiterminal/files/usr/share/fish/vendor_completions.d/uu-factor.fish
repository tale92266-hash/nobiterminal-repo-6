complete -c uu-factor -s h -l exponents -d 'Print factors in the form p^e'
complete -c uu-factor -l help -d 'Print help information.'
complete -c uu-factor -s V -l version -d 'Print version'
