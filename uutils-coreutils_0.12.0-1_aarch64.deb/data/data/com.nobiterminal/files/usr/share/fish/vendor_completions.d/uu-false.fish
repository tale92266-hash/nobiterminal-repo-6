complete -c uu-false -l help -d 'Print help information'
complete -c uu-false -l version -d 'Print version information'
