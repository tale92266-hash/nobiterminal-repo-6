complete -c uu-link -s h -l help -d 'Print help'
complete -c uu-link -s V -l version -d 'Print version'
