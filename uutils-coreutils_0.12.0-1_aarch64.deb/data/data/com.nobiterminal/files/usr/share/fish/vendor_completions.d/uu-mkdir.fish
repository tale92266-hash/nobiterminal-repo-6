complete -c uu-mkdir -s m -l mode -d 'set file mode (not implemented on windows)' -r
complete -c uu-mkdir -l context -d 'like -Z, or if CTX is specified then set the SELinux or SMACK security context to CTX' -r
complete -c uu-mkdir -s p -l parents -d 'make parent directories as needed'
complete -c uu-mkdir -s v -l verbose -d 'print a message for each printed directory'
complete -c uu-mkdir -s Z -d 'set SELinux security context of each created directory to the default type'
complete -c uu-mkdir -s h -l help -d 'Print help'
complete -c uu-mkdir -s V -l version -d 'Print version'
