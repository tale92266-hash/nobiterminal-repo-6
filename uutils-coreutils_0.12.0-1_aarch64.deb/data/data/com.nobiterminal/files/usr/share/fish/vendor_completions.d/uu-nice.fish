complete -c uu-nice -s n -l adjustment -d 'add N to the niceness (default is 10)' -r
complete -c uu-nice -s h -l help -d 'Print help'
complete -c uu-nice -s V -l version -d 'Print version'
