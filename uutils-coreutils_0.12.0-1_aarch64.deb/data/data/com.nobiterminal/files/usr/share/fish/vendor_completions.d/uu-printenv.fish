complete -c uu-printenv -s 0 -l null -d 'end each output line with 0 byte rather than newline'
complete -c uu-printenv -s h -l help -d 'Print help'
complete -c uu-printenv -s V -l version -d 'Print version'
