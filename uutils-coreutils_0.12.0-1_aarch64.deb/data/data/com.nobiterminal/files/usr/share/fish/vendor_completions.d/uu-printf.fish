complete -c uu-printf -l help -d 'Print help information'
complete -c uu-printf -l version -d 'Print version information'
