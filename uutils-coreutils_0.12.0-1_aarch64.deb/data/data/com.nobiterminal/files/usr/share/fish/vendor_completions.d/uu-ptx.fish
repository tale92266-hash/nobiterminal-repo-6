complete -c uu-ptx -s F -l flag-truncation -d 'use STRING for flagging line truncations' -r
complete -c uu-ptx -s M -l macro-name -d 'macro name to use instead of \'xx\'' -r
complete -c uu-ptx -l format -r -f -a "roff\t''
tex\t''"
complete -c uu-ptx -s S -l sentence-regexp -d 'for end of lines or end of sentences' -r
complete -c uu-ptx -s W -l word-regexp -d 'use REGEXP to match each keyword' -r
complete -c uu-ptx -s b -l break-file -d 'word break characters in this FILE' -r -F
complete -c uu-ptx -s g -l gap-size -d 'gap size in columns between output fields' -r
complete -c uu-ptx -s i -l ignore-file -d 'read ignore word list from FILE' -r -F
complete -c uu-ptx -s o -l only-file -d 'read only word list from this FILE' -r -F
complete -c uu-ptx -s w -l width -d 'output width in columns, reference excluded' -r
complete -c uu-ptx -s A -l auto-reference -d 'output automatically generated references'
complete -c uu-ptx -s G -l traditional -d 'behave more like System V \'ptx\''
complete -c uu-ptx -s O -d 'generate output as roff directives'
complete -c uu-ptx -s T -d 'generate output as TeX directives'
complete -c uu-ptx -s R -l right-side-refs -d 'put references at right, not counted in -w'
complete -c uu-ptx -s f -l ignore-case -d 'fold lower case to upper case for sorting'
complete -c uu-ptx -s r -l references -d 'first field of each line is a reference'
complete -c uu-ptx -s t -l typeset-mode -d 'change the default width from 72 to 100'
complete -c uu-ptx -s h -l help -d 'Print help'
complete -c uu-ptx -s V -l version -d 'Print version'
