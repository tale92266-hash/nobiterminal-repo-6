complete -c uu-pwd -s L -l logical -d 'use PWD from environment, even if it contains symlinks'
complete -c uu-pwd -s P -l physical -d 'avoid all symlinks'
complete -c uu-pwd -s h -l help -d 'Print help'
complete -c uu-pwd -s V -l version -d 'Print version'
