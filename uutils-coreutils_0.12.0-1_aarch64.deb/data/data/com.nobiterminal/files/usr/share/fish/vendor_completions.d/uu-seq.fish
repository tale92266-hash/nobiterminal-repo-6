complete -c uu-seq -s s -l separator -d 'Separator character (defaults to \\n)' -r
complete -c uu-seq -s t -l terminator -d 'Terminator character (defaults to \\n)' -r
complete -c uu-seq -s f -l format -d 'use printf style floating-point FORMAT' -r
complete -c uu-seq -s w -l equal-width -d 'Equalize widths of all numbers by padding with zeros'
complete -c uu-seq -s h -l help -d 'Print help'
complete -c uu-seq -s V -l version -d 'Print version'
