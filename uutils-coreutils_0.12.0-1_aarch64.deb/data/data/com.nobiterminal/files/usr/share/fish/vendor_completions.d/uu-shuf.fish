complete -c uu-shuf -s i -l input-range -d 'treat each number LO through HI as an input line' -r
complete -c uu-shuf -s n -l head-count -d 'output at most COUNT lines' -r
complete -c uu-shuf -s o -l output -d 'write result to FILE instead of standard output' -r -F
complete -c uu-shuf -l random-seed -d 'seed with STRING for reproducible output' -r -f
complete -c uu-shuf -l random-source -d 'get random bytes from FILE' -r -F
complete -c uu-shuf -s e -l echo -d 'treat each ARG as an input line'
complete -c uu-shuf -s r -l repeat -d 'output lines can be repeated'
complete -c uu-shuf -s z -l zero-terminated -d 'line delimiter is NUL, not newline'
complete -c uu-shuf -s h -l help -d 'Print help'
complete -c uu-shuf -s V -l version -d 'Print version'
