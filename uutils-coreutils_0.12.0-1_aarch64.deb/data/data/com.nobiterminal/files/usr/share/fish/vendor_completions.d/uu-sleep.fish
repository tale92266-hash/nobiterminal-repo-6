complete -c uu-sleep -s h -l help -d 'Print help'
complete -c uu-sleep -s V -l version -d 'Print version'
