complete -c uu-test -s h -l help -d 'Print help'
complete -c uu-test -s V -l version -d 'Print version'
