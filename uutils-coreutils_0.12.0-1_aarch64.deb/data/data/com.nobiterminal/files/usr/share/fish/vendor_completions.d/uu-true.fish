complete -c uu-true -l help -d 'Print help information'
complete -c uu-true -l version -d 'Print version information'
