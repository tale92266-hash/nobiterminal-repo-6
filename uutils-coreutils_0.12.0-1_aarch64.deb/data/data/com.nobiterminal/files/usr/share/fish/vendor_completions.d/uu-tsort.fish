complete -c uu-tsort -s w
complete -c uu-tsort -s h -l help -d 'Print help'
complete -c uu-tsort -s V -l version -d 'Print version'
