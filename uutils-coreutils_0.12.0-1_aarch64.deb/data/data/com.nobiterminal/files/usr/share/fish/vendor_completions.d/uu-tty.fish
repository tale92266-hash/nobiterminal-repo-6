complete -c uu-tty -s s -l silent -l quiet -d 'print nothing, only return an exit status'
complete -c uu-tty -s h -l help -d 'Print help'
complete -c uu-tty -s V -l version -d 'Print version'
