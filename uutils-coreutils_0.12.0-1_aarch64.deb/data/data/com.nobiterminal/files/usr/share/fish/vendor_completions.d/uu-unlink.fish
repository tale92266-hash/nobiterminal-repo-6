complete -c uu-unlink -s h -l help -d 'Print help'
complete -c uu-unlink -s V -l version -d 'Print version'
