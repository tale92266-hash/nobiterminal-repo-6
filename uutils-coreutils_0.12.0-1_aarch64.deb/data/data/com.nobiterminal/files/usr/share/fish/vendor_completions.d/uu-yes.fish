complete -c uu-yes -s h -l help -d 'Print help'
complete -c uu-yes -s V -l version -d 'Print version'
