#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "valkey::valkey" for configuration "Release"
set_property(TARGET valkey::valkey APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(valkey::valkey PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libvalkey.a"
  )

list(APPEND _cmake_import_check_targets valkey::valkey )
list(APPEND _cmake_import_check_files_for_valkey::valkey "/data/data/com.nobiterminal/files/usr/lib/libvalkey.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
