// SPDX-License-Identifier: Apache-2.0
// SPDX-FileCopyrightText: Copyright The WasmEdge Authors

//===-- wasmedge/version.h - WasmEdge C API -------------------------------===//
//
// Part of the WasmEdge Project.
//
//===----------------------------------------------------------------------===//
///
/// \file
/// This file contains the version definitions of the WasmEdge C API.
///
//===----------------------------------------------------------------------===//

#ifndef WASMEDGE_C_API_VERSION_H
#define WASMEDGE_C_API_VERSION_H

// WasmEdge version.
#define WASMEDGE_VERSION "0.18.1"
#define WASMEDGE_VERSION_MAJOR 0
#define WASMEDGE_VERSION_MINOR 18
#define WASMEDGE_VERSION_PATCH 1

#define WasmEdge_Plugin_CurrentAPIVersion 5

#endif // WASMEDGE_C_API_VERSION_H
