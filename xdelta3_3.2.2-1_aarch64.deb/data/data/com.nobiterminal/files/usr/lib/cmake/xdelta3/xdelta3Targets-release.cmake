#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "xdelta3::xdelta3" for configuration "Release"
set_property(TARGET xdelta3::xdelta3 APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(xdelta3::xdelta3 PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "/data/data/com.nobiterminal/files/usr/lib/libxdelta3.a"
  )

list(APPEND _cmake_import_check_targets xdelta3::xdelta3 )
list(APPEND _cmake_import_check_files_for_xdelta3::xdelta3 "/data/data/com.nobiterminal/files/usr/lib/libxdelta3.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
