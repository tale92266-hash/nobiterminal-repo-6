--!A cross-platform build utility based on Lua
--
-- Licensed under the Apache License, Version 2.0 (the "License");
-- you may not use this file except in compliance with the License.
-- You may obtain a copy of the License at
--
--     http://www.apache.org/licenses/LICENSE-2.0
--
-- Unless required by applicable law or agreed to in writing, software
-- distributed under the License is distributed on an "AS IS" BASIS,
-- WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
-- See the License for the specific language governing permissions and
-- limitations under the License.
--
-- Copyright (C) 2015-present, Xmake Open Source Community.
--
-- @author      ruki
-- @file        main.lua
--

-- imports
import("core.base.option")
import("core.base.task")
import("core.project.config")
import("core.project.project")
import("core.platform.platform")
import("core.base.privilege")
import("privilege.sudo")
import("install")
import("private.action.utils", {alias = "action_utils"})

-- check targets
function _check_targets(targetnames, group_pattern)

    -- get targets
    local targets = action_utils.get_targets(targetnames, {group_pattern = group_pattern})

    -- filter and check targets with builtin-install script
    local targetnames = {}
    for _, target in ipairs(targets) do
        if target:targetfile() and target:is_enabled() and not target:script("install") then
            local targetfile = target:targetfile()
            if targetfile and not os.isfile(targetfile) then
                table.insert(targetnames, target:name())
            end
        end
    end

    -- there are targets that have not yet been built?
    if #targetnames > 0 then
        raise("please run `$xmake build [target]` to build the following targets first:\n  -> " .. table.concat(targetnames, '\n  -> '))
    end
end

function main()

    -- load config first
    task.run("config", {require = false}, {disable_dump = true})

    -- check targets first
    local targetnames, group_pattern = action_utils.get_targets_and_group()
    _check_targets(targetnames, group_pattern)

    -- get the install targets argument, it may be a list of target names or the magic "__all"/"__def"
    local targets_arg = targetnames or (option.get("all") and "__all" or "__def")

    -- attempt to install directly
    try
    {
        function ()
            install(targets_arg, group_pattern)
            cprint("${color.success}install ok!")
        end,

        catch
        {
            -- failed or not permission? request administrator permission and install it again
            function (errors)

                -- try get privilege
                if privilege.get() then
                    local ok = try
                    {
                        function ()
                            install(targets_arg, group_pattern)
                            cprint("${color.success}install ok!")
                            return true
                        end
                    }

                    -- release privilege
                    privilege.store()
                    if ok then
                        return
                    end
                end

                -- continue to install with administrator permission?
                local ok = false
                if sudo.has() and option.get("admin") then

                    -- install target with administrator permission
                    sudo.execl(path.join(os.scriptdir(), "install_admin.lua"), {
                        type(targets_arg) == "table" and table.concat(targets_arg, path.envsep()) or targets_arg,
                        group_pattern or "", option.get("installdir") or "",
                        option.get("bindir"),
                        option.get("libdir"),
                        option.get("includedir")})
                    cprint("${color.success}install ok!")
                    ok = true
                end
                if not ok then
                    local syserror = os.syserror()
                    if syserror == os.SYSERR_NOT_PERM or syserror == os.SYSERR_NOT_ACCESS then
                        wprint("please pass the --admin parameter to `xmake install` to request administrator permissions!")
                    end
                end
                assert(ok, "install failed, %s", errors or "unknown reason")
            end
        }
    }
end
